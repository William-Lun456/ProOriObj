/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package principal;

import autenticacion.ServicioLogin;
import java.util.Scanner;
import java.util.ArrayList;
import modelos.Tecnico;
import modelos.Vehiculo;
import servicios.ServicioCliente;
import servicios.ServicioVehiculo;
import servicios.ServicioTecnico;
import servicios.ServicioPlan;

public class Main {

    public static void main(String[] args) {
        
        ArrayList<Tecnico> listaTecnicos = new ArrayList<>();
        ArrayList<Vehiculo> listaVehiculos = new ArrayList<>();
        
        Scanner sc = new Scanner(System.in);
        ServicioLogin login = new ServicioLogin(sc); // Autenticación
        ServicioCliente servicioCliente = new ServicioCliente();
        ServicioVehiculo servicioVehiculo = new ServicioVehiculo(listaVehiculos); 
        ServicioTecnico servicioTecnico = new ServicioTecnico(listaTecnicos);    
        ServicioPlan servicioPlan = new ServicioPlan(listaTecnicos, listaVehiculos); 

        
        //Este metodo lee  desde el archivo CSV al iniciar el programa.
        servicioCliente.cargarClientesDesdeArchivo();
        servicioTecnico.cargarTecnicoDesdeArchivo();
        servicioVehiculo.cargarVehiculoDesdeArchivo();
        servicioPlan.cargarMantenimientosDesdeArchivo();

        // Validar inicio de sesión
        // si falla muestra el mensaje y cierra el programa
        if (!login.autenticacion()) {
            System.out.println("Acceso denegado. Cerrando sistema.");
            return; 
        }
     
        int opcion = -1; // Variable para guardar la opcion del usuario
        do {
            // Mostramos el menu principal
            System.out.println("\n=== SISTEMA DE TRANSPORTE SUR PERUANO ===");
            System.out.println("1. Mantenimiento de Clientes");
            System.out.println("2. Mantenimiento de Tecnicos");
            System.out.println("3. Mantenimiento de Vehiculos");
            System.out.println("4. Plan de Mantenimiento");
            System.out.println("5. Salir");

            System.out.print("Opcion: ");
            String entrada = sc.nextLine(); // Leemos lo que el usuario escribe como texto

            // Si el usuario solo presiona ENTER sin escribir nada
            if (entrada.isEmpty()) {
                System.out.println("Debes ingresar una opcion numerica del 1 al 5.");
                continue; // Volver al menu
            }
            //bloque que podria causar un error
            try {
                // Intentamos convertir el texto a numero
                opcion = Integer.parseInt(entrada);
                //atrapa el error
            } catch (NumberFormatException e) {
                // Si el usuario escribe letras o simbolos que no son numeros
                System.out.println("Entrada invalida. Ingresa solo numeros del 1 al 5.");
                continue; // Volver al menu
            }

            // Evaluamos la opcion ingresada
            switch (opcion) {
                case 1:
                    servicioCliente.MenuClientes(); // Llama al menu de clientes
                    break;
                case 2:
                    servicioTecnico.MenuTecnicos(); // Llama al menu de tecnicos
                    break;
                case 3:
                    servicioVehiculo.MenuVehiculos(); // Llama al menu de vehiculos
                    break;
                case 4:
                    servicioPlan.MenuMantenimiento(); // Llama al menu de mantenimiento
                    break;
                case 5:
                    // Antes de salir, guardamos los datos en archivos
                    servicioCliente.guardarClientesEnArchivo();
                    servicioVehiculo.guardarVehiculoEnArchivo();
                    servicioTecnico.guardarTecnicoEnArchivo();
                    servicioPlan.guardarMantenimientosEnArchivo();
                    System.out.println("Gracias por usar el sistema.");
                    break;
                default:
                    // Si el numero no esta entre 1 y 5
                    System.out.println("Opcion invalida. Ingresa un numero del 1 al 5.");
            }

        } while (opcion != 5); // Repetir hasta que se elija salir (opcion 5)
    }
}