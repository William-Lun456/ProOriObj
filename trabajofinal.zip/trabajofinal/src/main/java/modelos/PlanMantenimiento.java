/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

public class PlanMantenimiento {
     private String codigo;
    private String datosTecnico;
    private String tipoMantenimiento;
    private String datosVehiculo;
    private int kilometraje;
    private String fallaVehiculo;
    private  String fechaMantenimiento;
    private  double servicioMantenimiento;

    public PlanMantenimiento(String codigo, String datosTecnico, String tipoMantenimiento, String datosVehiculo,int kilometraje, String fallaVehiculo, String fechaMantenimiento, double servicioMantenimiento) {
        this.codigo = codigo;
        this.datosTecnico = datosTecnico;
        this.tipoMantenimiento = tipoMantenimiento;
        this.datosVehiculo = datosVehiculo;
        this.kilometraje = kilometraje;
        this.fallaVehiculo = fallaVehiculo;
        this.fechaMantenimiento = fechaMantenimiento;
        this.servicioMantenimiento = servicioMantenimiento;
    }

    // Getters y Setters
    public String getCodigo() { return codigo; }
    public String getDatosTecnico() { return datosTecnico; }
    public String getTipoMantenimiento() { return tipoMantenimiento; }
    public String getDatosVehiculo() { return datosVehiculo; }
    public int getKilometraje() { return kilometraje; }
    public String getFallaVehiculo() { return fallaVehiculo; }
    public String getFechaMantenimiento() { return fechaMantenimiento; }
    public double getServicioMantenimiento() { return servicioMantenimiento; }
    
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setDatosTecnico(String datosTecnico) {
        this.datosTecnico = datosTecnico;
    }

    public void setTipoMantenimiento(String tipoMantenimiento) {
        this.tipoMantenimiento = tipoMantenimiento;
    }

    public void setDatosVehiculo(String datosVehiculo) {
        this.datosVehiculo = datosVehiculo;
    }

    public void setKilometraje(int kilometraje) {
        this.kilometraje = kilometraje;
    }

    public void setFallaVehiculo(String fallaVehiculo) {
        this.fallaVehiculo = fallaVehiculo;
    }

    public void setFechaMantenimiento(String fechaMantenimiento) {
        this.fechaMantenimiento = fechaMantenimiento;
    }

    public void setServicioMantenimiento(double servicioMantenimiento) {
        this.servicioMantenimiento = servicioMantenimiento;
    }

    @Override
    public String toString() {
        return "Mantenimiento{" +
                "codigo=" + codigo +
                ", datosTecnico='" + datosTecnico + '\'' +
                ", tipoMantenimiento='" + tipoMantenimiento + '\'' +
                ", datosVehiculo='" + datosVehiculo + '\'' +
                ", kilometraje=" + kilometraje +
                ", fallaVehiculo='" + fallaVehiculo + '\'' +
                ", fechaMantenimiento='" + fechaMantenimiento + '\'' +
                ", servicioMantenimiento=" + servicioMantenimiento +
                '}';
    }
}


