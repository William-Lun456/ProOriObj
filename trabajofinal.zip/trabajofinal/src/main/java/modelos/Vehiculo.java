/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

public class Vehiculo {
    private String codigo;
    private String placa;
    private String numeroSerie;
    private String anioFabricacion;
    private String color;
    private int cantidadPuertas;
    private String cilindrada;
    private String duenio;
    
    public Vehiculo (String codigo, String placa, String numeroSerie, String anioFabricacion, String color , int cantidadPuertas,  String cilindrada, String duenio ){
        this.codigo = codigo;
        this.placa = placa;
        this.numeroSerie = numeroSerie;
        this.anioFabricacion = anioFabricacion;
        this.color= color;
        this.cantidadPuertas = cantidadPuertas;
        this.cilindrada = cilindrada;
        this.duenio = duenio;
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }
    public String getnumeroSerie() {
        return numeroSerie;
    }

    public void setAnioFabricacion(String anioFabricacion) {
        this.anioFabricacion = anioFabricacion;
    }
    public String getAnioFabricacion() {
        return anioFabricacion;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    public String getColor() {
        return color;
    }
    
    public void setCantidadPuertas(int cantidadPuertas) {
        this.cantidadPuertas = cantidadPuertas;
    }
    public int getCantidadPuertas() {
        return cantidadPuertas;
    }
    
    public void setCilindrada(String cilindrada) {
        this.cilindrada = cilindrada;
    }
    public String getCilindrada() {
        return cilindrada;
    }
    
    public void setDuenio(String duenio) {
        this.duenio = duenio;
    }
    public String getDuenio() {
        return duenio;
    }
    
    public void mostrar() {
        System.out.println("Codigo: " + codigo);
        System.out.println("Placa: " + placa );
        System.out.println("Numero de serie: " + numeroSerie);
        System.out.println("Anio de Fabricacion: " + anioFabricacion);
        System.out.println("Color: " + color);
        System.out.println("Cantidad de Puertas: " + cantidadPuertas);
        System.out.println("Cilindrada: " + cilindrada);
        System.out.println("Duenio: " + duenio);
    }
}
