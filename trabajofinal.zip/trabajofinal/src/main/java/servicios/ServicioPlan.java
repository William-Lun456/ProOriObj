/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

import modelos.PlanMantenimiento;
import modelos.Tecnico;
import modelos.Vehiculo;
import java.util.ArrayList;
import java.util.Scanner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat; //formato dd/mm/yyyy
import java.util.Date; //representa hora y fecha exacta
import java.util.InputMismatchException; // Se usa para evitar errores cuando el usuario escribe letras en lugar de numeros.




public class ServicioPlan {
    private ArrayList<PlanMantenimiento> listaMantenimientos  = new ArrayList<>();
    private ArrayList<Tecnico> tecnicos; // referencia ( no se crea nuevo)
    private ArrayList<Vehiculo> vehiculos;
    private Scanner sc = new Scanner(System.in);
    
    //constructor que recibe la lista desde afuera
    public ServicioPlan(ArrayList<Tecnico> tecnicos, ArrayList<Vehiculo> vehiculos) {
    this.tecnicos = tecnicos;     // guarda la lista de técnicos que se envia desde fuera
    this.vehiculos = vehiculos;   // guarda la lista de vehículos que se envia desde fuera
    }
    
    
    public void MenuMantenimiento(){
        cargarMantenimientosDesdeArchivo();
        boolean salir = false;
        int opcion;
        while (!salir){
            System.out.println("\n--- PLAN DE MANTENIMIENTO ---");
            System.out.println("1. Insertar mantenimiento");
            System.out.println("2. Buscar mantenimiento");
            System.out.println("3. Modificar mantenimiento");
            System.out.println("4. Eliminar mantenimiento");
            System.out.println("5. Listar mantenimiento");
            System.out.println("6. Volver al menu mantenimiento");
            System.out.println("7. Volver al menu principal");
            
            System.out.print("Opcion: ");
            String entrada = sc.nextLine(); // Leemos lo que el usuario escribe como texto

            // Validamos si el usuario solo presiona ENTER sin escribir nada
            if (entrada.isEmpty()) {
                System.out.println("Debes escribir un numero del 1 al 7.");
                continue; // Volvemos al inicio del while para mostrar el menu de nuevo
            }
            //intenta ejecutar que algo saldria mal 
            try {
                // Intentamos convertir el texto a numero entero
                opcion = Integer.parseInt(entrada);
                // Evaluamos la opcion del usuario
                switch (opcion) {
                    case 1: InsertarMantenimiento();
                    break;
                    case 2: BuscarMantenimiento();
                        break;
                    case 3 : ModificarMantenimiento();
                        break;
                    case 4 : EliminarMantenimiento();
                        break;
                    case 5 : ListarMantenimiento();
                        break;
                    case 6 : 
                       System.out.println("Regresando al menu de Tecnico");
                        break;
                    case 7 :      
                       System.out.println("Regresando al menu principal");
                       salir = true;  
                        break; 
                    default:
                        System.out.println("Opcion no valida. Elige un numero del 1 al 7.");
                        break;
                }
             //cae en el error o atrapa el error
            } catch (NumberFormatException e) {
             
                System.out.println("Entrada invalida. Escribe solo numeros del 1 al 7.");
            }
        }    
    }
    
    public void InsertarMantenimiento() {
        System.out.println("\n--- INSERTAR MANTENIMIENTO ---");

        boolean validador = false;
        String codigo = null;

        // Validar codigo unico
        do {
            System.out.print("Codigo del mantenimiento: ");
            codigo = sc.nextLine().trim();

            if (codigo.equals("")) {
                System.out.println("Escriba un codigo");
            } else if (existeCodigo(codigo)) {
                System.out.println("El codigo ya existe, ingrese otro.");
            } else {
                validador = true;
            }
        } while (!validador);
        
      
        // Validar que el tecnico exista
        // Paso 1: Declaramos la variable 'tecnico' como vacia (null)
        Tecnico tecnico = null;

        // Paso 2: Repetir hasta que encontremos un tecnico valido
        while (tecnico == null) {

            // Mostrar mensaje pidiendo el codigo del tecnico
            System.out.print("Codigo del tecnico: ");

            // Leer lo que escribio el usuario (el codigo del tecnico)
            String codigoTecnico = sc.nextLine().trim();

            // Llamar al metodo 'buscarTecnicoPorCodigo' para ver si ese tecnico existe
            tecnico = buscarTecnicoPorCodigo(codigoTecnico);

            // Si tecnico sigue siendo null, significa que NO se encontro
            if (tecnico == null) {
                // Mostrar mensaje de error y repetir
                System.out.println("Error: El tecnico no esta registrado. Intente nuevamente.");
            }
        }

        // Paso 3: Si salimos del bucle, significa que encontramos un tecnico
        // Ahora creamos una variable llamada 'datosTecnico' que tiene el nombre completo
        String datosTecnico = tecnico.getNombres() + " " + tecnico.getApellidos();

        // Paso 4: Mostrar los datos del tecnico encontrados
        System.out.println("Tecnico encontrado");
        System.out.println("Nombres: " + tecnico.getNombres());
        System.out.println("Apellidos: " + tecnico.getApellidos());
        System.out.println("Especialidad: " + tecnico.getEspecialidad());

       
        System.out.print("Tipo de mantenimiento: ");
        String tipoMantenimiento = sc.nextLine();
        
        
        // Validar que el vehiculo exista 
        Vehiculo vehiculo = null;
        while (vehiculo == null) {
            System.out.print("Codigo del vehiculo: ");
            String datosVehiculo = sc.nextLine().trim();
            
            vehiculo = buscarVehiculoPorCodigo(datosVehiculo);
            if (vehiculo == null) {
                System.out.println("Error: El vehiculo no esta registrado. Intente nuevamente.");
            }
        }
        
        // Guardar los datos como texto resumido para el mantenimiento
        String datosVehiculo = vehiculo.getPlaca() + " - " + vehiculo.getDuenio();
        // Mostrar los datos del vehiculo encontrado
        System.out.println("Vehiculo encontrado:");
        System.out.println("Placa: " + vehiculo.getPlaca());
        System.out.println("N Serie: " + vehiculo.getnumeroSerie());
        System.out.println("Cilindrada: " + vehiculo.getCilindrada());
        System.out.println("Duenio: " + vehiculo.getDuenio());
        

        
        System.out.print("Kilometraje: ");
        int kilometraje = sc.nextInt();
        sc.nextLine(); // Limpiar buffer

        System.out.print("Falla del vehiculo: ");
        String fallaVehiculo = sc.nextLine();

        
        String fechaMantenimiento = "";
        boolean fechaValida = false;
        while (!fechaValida) {
            System.out.print("Fecha de mantenimiento (dd/mm/aaaa): ");
            fechaMantenimiento = sc.nextLine();

            // Validar que el formato sea correcto: dd/mm/aaaa
            if (fechaMantenimiento.matches("^\\d{1,2}/\\d{1,2}/\\d{4}$")) {
                // Validar que la fecha realmente exista
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                //sirve para leer fechas en formato dd/mm/yyyy
                sdf.setLenient(false); // Esto evita fechas falsas como 31/02/2025
                try {
                    //convierte la caden de texto fechamantenimiento en una fecha real
                    Date fecha = sdf.parse(fechaMantenimiento); // Si no lanza error, la fecha es valida
                    fechaValida = true;
                } catch (Exception e) {
                    System.out.println("La fecha ingresada no existe. Intentalo otra vez.");
                }
            } else {
                System.out.println("Formato invalido. Usa exactamente dd/mm/aaaa (por ejemplo: 17/07/2025)");
            }
        }

        // Declaramos la variable que almacenara el costo del mantenimiento
        double servicioMantenimiento = 0;

        // Esta variable controla si el valor ingresado es valido
        boolean valido = false;

        // Bucle que se repetira hasta que se ingrese un numero valido y positivo
        while (!valido) {
            System.out.print("Costo del servicio de mantenimiento: ");

            try {
                // Intentamos leer un numero decimal (double) desde el teclado
                servicioMantenimiento = sc.nextDouble();

                // Verificamos si el numero es negativo
                if (servicioMantenimiento < 0) {
                    System.out.println("El costo no puede ser negativo. Intente nuevamente.");
                } else {
                    // Si es un numero valido y positivo, salimos del bucle
                    valido = true;
                }

            } catch (InputMismatchException e) {
                // Si se ingresa texto o simbolos en lugar de un numero, se produce una excepcion
                System.out.println("Ingrese un numero valido (no letras).");

                // Limpiamos el buffer del scanner para evitar bucle infinito
                sc.nextLine();
            }
        }

        PlanMantenimiento nuevoMantenimiento = new PlanMantenimiento(
            codigo,
            datosTecnico,
            tipoMantenimiento,
            datosVehiculo,
            kilometraje,
            fallaVehiculo,
            fechaMantenimiento,
            servicioMantenimiento
        );

        listaMantenimientos.add(nuevoMantenimiento);
        System.out.println("Mantenimiento registrado correctamente.");
        guardarMantenimientosEnArchivo();
    }
    
    
    public void BuscarMantenimiento() {
        Scanner sc = new Scanner(System.in); //Lector para que el usuario escriba algo

        System.out.println("\n--- BUSCAR MANTENIMIENTO ---");
        System.out.print("Ingrese el codigo del mantenimiento: ");
        String codigoBuscado = sc.nextLine(); //Lo que escribe el usuario

        boolean encontrado = false; //Para saber si encontramos el mantenimiento

        //Recorremos cada objeto de tipo PlanMantenimiento en la lista
        for (PlanMantenimiento pm : listaMantenimientos) {
            if (pm.getCodigo().equalsIgnoreCase(codigoBuscado)) {
                // Si el codigo coincide, mostramos la informacion
                System.out.println("\nMantenimiento encontrado");
                System.out.println("Codigo                : " + pm.getCodigo());
                System.out.println("Datos del Tecnico     : " + pm.getDatosTecnico());
                System.out.println("Tipo de Mantenimiento : " + pm.getTipoMantenimiento());
                System.out.println("Datos del Vehiculo    : " + pm.getDatosVehiculo());
                System.out.println("Kilometraje           : " + pm.getKilometraje());
                System.out.println("Falla del Vehiculo    : " + pm.getFallaVehiculo());
                System.out.println("Fecha de Mantenimiento: " + pm.getFechaMantenimiento());
                System.out.println("Costo del Servicio    : " + pm.getServicioMantenimiento());
                encontrado = true;
                break;
            }
        }
        //Si no encontramos nada
        if (!encontrado) {
            System.out.println("No se encontro ningun mantenimiento con ese codigo.");
        }
    }
    
    
    public void ModificarMantenimiento() {
        System.out.println("\n--- MODIFICAR MANTENIMIENTO ---");
        sc.nextLine(); // limpiar scanner

        System.out.print("Ingrese el codigo del mantenimiento: ");
        String codigo = sc.nextLine();

        for (PlanMantenimiento pm : listaMantenimientos) {
            if (pm.getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("Se encontro el mantenimiento.");
                boolean continuar = true;

                while (continuar) {
                    int opcion = 0;

                    while (true) {
                        System.out.println("\nQue desea modificar?");
                        System.out.println("1. Datos del tecnico");
                        System.out.println("2. Tipo de mantenimiento");
                        System.out.println("3. Datos del vehiculo");
                        System.out.println("4. Kilometraje");
                        System.out.println("5. Falla del vehiculo");
                        System.out.println("6. Fecha de mantenimiento");
                        System.out.println("7. Costo del servicio");
                        System.out.println("8. Terminar modificaciones");
                        System.out.print("Elija una opcion (1-8): ");

                        if (sc.hasNextInt()) {
                            opcion = sc.nextInt();
                            sc.nextLine(); // limpiar buffer

                            if (opcion >= 1 && opcion <= 8) break;
                            else System.out.println("Opcion fuera de rango.");
                        } else {
                            System.out.println("Debe ingresar un numero.");
                            sc.nextLine(); // limpiar entrada invalida
                        }
                    }

                    switch (opcion) {
                        case 1:
                             boolean tecnicoValido = false;

                            while (!tecnicoValido) {
                                System.out.print("Ingrese el codigo del tecnico: ");
                                String codigoTecnico = sc.nextLine();

                                for (Tecnico t : tecnicos) {
                                    if (t.getCodigo().equalsIgnoreCase(codigoTecnico)) {
                                        System.out.println("Tecnico encontrado:");
                                        System.out.println("Codigo: " + t.getCodigo());
                                        System.out.println("Nombre: " + t.getNombres());
                                        System.out.println("Apellidos: " + t.getApellidos());
                                        System.out.println("Especialidad: " + t.getEspecialidad());
                                        // Actualiza los datos del mantenimiento
                                        pm.setDatosTecnico(t.toString());
                                        tecnicoValido = true; // salimos del bucle
                                        break;
                                    }
                                }
                                if (!tecnicoValido) {
                                    System.out.println("No se encontro tecnico con ese codigo. Intente nuevamente.");
                                }
                            }
                            break;

                        case 2:
                            System.out.print("Ingrese nuevo tipo de mantenimiento: ");
                            String nuevoTipo = sc.nextLine();
                            pm.setTipoMantenimiento(nuevoTipo);
                            System.out.println("Tipo actualizado.");
                            break;

                        case 3:
                            boolean vehiculoValido = false;

                            while (!vehiculoValido) {
                                System.out.print("Ingrese el codigo del vehiculo: ");
                                String codigoVehiculo = sc.nextLine();

                                for (Vehiculo v : vehiculos) {
                                    if (v.getCodigo().equalsIgnoreCase(codigoVehiculo)) {
                                        System.out.println("Vehiculo encontrado:");
                                        System.out.println("Placa: " + v.getPlaca());
                                        System.out.println("N° Serie: " + v.getnumeroSerie());
                                        System.out.println("Anio fabricacion: " + v.getAnioFabricacion());

                                        // Actualiza los datos del mantenimiento
                                        pm.setDatosVehiculo(v.toString());
                                        vehiculoValido = true; // salimos del bucle
                                        break;
                                    }
                                }
                                if (!vehiculoValido) {
                                    System.out.println("No se encontro vehiculo con ese codigo. Intente nuevamente.");
                                }
                            }
                            break;


                        case 4:
                            System.out.print("Ingrese nuevo kilometraje: ");
                            int nuevoKm = sc.nextInt();
                            sc.nextLine();
                            pm.setKilometraje(nuevoKm);
                            System.out.println("Kilometraje actualizado.");
                            break;

                        case 5:
                            System.out.print("Ingrese nueva falla del vehiculo: ");
                            String nuevaFalla = sc.nextLine();
                            pm.setFallaVehiculo(nuevaFalla);
                            System.out.println("Falla actualizada.");
                            break;

                        case 6:
                            String nuevaFecha = "";
                            boolean fechaValida = false;

                            while (!fechaValida) {
                                System.out.print("Ingrese nueva fecha de mantenimiento (dd/mm/aaaa): ");
                                nuevaFecha = sc.nextLine();

                                // Validar que tenga el formato correcto: dd/mm/aaaa
                                if (nuevaFecha.matches("^\\d{2}/\\d{2}/\\d{4}$")) {
                                    // Crear un validador de fechas
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                    sdf.setLenient(false); // Esto hace que fechas como 31/02/2025 sean rechazadas

                                    try {
                                        Date fecha = sdf.parse(nuevaFecha); // Intenta convertir el texto en una fecha real
                                        fechaValida = true; // Si no lanza error, entonces la fecha es valida
                                    } catch (Exception e) {
                                        System.out.println("La fecha ingresada no existe. Intenta otra vez.");
                                    }
                                } else {
                                    System.out.println("Formato invalido. Usa el formato dd/mm/aaaa (por ejemplo: 17/07/2025).");
                                }
                            }

                            pm.setFechaMantenimiento(nuevaFecha); // Asignar la nueva fecha validada al objeto
                            System.out.println("Fecha actualizada.");
                            break;

                        case 7:
                            double nuevoCosto = 0;
                            boolean valido = false;
                            // Bucle para validar que el costo sea un numero positivo
                            while (!valido) {
                                System.out.print("Modificar el costo del servicio: ");
                                try {
                                    nuevoCosto = sc.nextDouble();

                                    if (nuevoCosto < 0) {
                                        System.out.println("El costo no puede ser negativo. Intente nuevamente.");
                                    } else {
                                        valido = true; // numero valido
                                    }
                                } catch (InputMismatchException e) {
                                    System.out.println("Ingrese un numero valido (no letras).");
                                    sc.nextLine(); // limpiar el buffer del scanner
                                }
                            }

                            // Asignamos el nuevo costo validado
                            pm.setServicioMantenimiento(nuevoCosto);
                            System.out.println("Costo actualizado.");
                            break;

                        case 8:
                            continuar = false;
                            break;
                    }

                    if (continuar) {
                        System.out.print("Desea modificar otro dato? (si/no): ");
                        String respuesta = sc.nextLine().trim().toLowerCase();
                        if (respuesta.equals("no")) continuar = false;
                    }
                }

                System.out.println("Datos del mantenimiento modificados correctamente.");
                guardarMantenimientosEnArchivo(); // guarda los cambios en el archivo
                return;
            }
        }

        System.out.println("No se encontro mantenimiento con ese codigo.");
    }
    
    
    public void EliminarMantenimiento() {
    System.out.println("\n--- ELIMINAR MANTENIMIENTO ---");
    sc.nextLine(); // limpiar el buffer del scanner

    System.out.print("Ingrese el codigo del mantenimiento a eliminar: ");
    String codigo = sc.nextLine();
    // Bandera para saber si se encontro y elimino
    boolean eliminado = false;
    // Recorremos la lista de mantenimientos
    for (PlanMantenimiento pm : listaMantenimientos) {
        if (pm.getCodigo().equalsIgnoreCase(codigo)) {
            // Si el codigo coincide, lo eliminamos
            listaMantenimientos.remove(pm);
            eliminado = true;
            System.out.println("Mantenimiento eliminado correctamente.");
            guardarMantenimientosEnArchivo(); // actualiza el archivo .csv
            break;
        }
    }
        if (!eliminado) {
            System.out.println("No se encontro mantenimiento con ese codigo.");
        }
    
    }
    
    
    public void ListarMantenimiento() {
        System.out.println("\n--- LISTA DE MANTENIMIENTOS ---");

        if (listaMantenimientos.isEmpty()) {
            System.out.println("No hay mantenimientos registrados.");
            return;
        }
        // Recorremos toda la lista de mantenimientos y los mostramos
        for (PlanMantenimiento pm : listaMantenimientos) {
            System.out.println("Codigo: " + pm.getCodigo());
            System.out.println("Tecnico: " + pm.getDatosTecnico());
            System.out.println("Tipo de mantenimiento: " + pm.getTipoMantenimiento());
            System.out.println("Vehiculo: " + pm.getDatosVehiculo());
            System.out.println("Kilometraje: " + pm.getKilometraje());
            System.out.println("Falla: " + pm.getFallaVehiculo());
            System.out.println("Fecha: " + pm.getFechaMantenimiento());
            System.out.println("Servicio (Pago): S/ " + pm.getServicioMantenimiento());
            System.out.println("--------------------------------------");
        }
    }
    


    // Metodo auxiliar para validar si el codigo ya existe
    private boolean existeCodigo(String codigo) {
        for (PlanMantenimiento pm : listaMantenimientos) {
            if (pm.getCodigo().equalsIgnoreCase(codigo)) {
                return true;
            }
        }
        return false;
    }
    
    // Metodo que busca un tecnico por su codigo en la lista 'tecnicos'
    private Tecnico buscarTecnicoPorCodigo(String codigo) {
        //Para cada tecnico t dentro de la lista llamada tecnicos…
        for (Tecnico t : tecnicos) {
            //si son iguales entonces se encontro al tecnico
            if (t.getCodigo().equalsIgnoreCase(codigo)) {
                return t; // Lo encontro
            }
        }
        return null; // No lo encontro
    }
    
    //Metodo que busca un vehiculos por su codigo en la lista 'vehiculos'
    private Vehiculo buscarVehiculoPorCodigo(String codigo) {
        for (Vehiculo v : vehiculos) {
            if (v.getCodigo().equalsIgnoreCase(codigo)) {
                return v;
            }
        }
        return null;
    } 
    
    public void guardarMantenimientosEnArchivo() {
        try (PrintWriter pw = new PrintWriter("data/mantenimientos.csv")) {
            pw.println("Codigo, DatosTecnico, TipoMantenimiento, DatosVehiculo, Kilometraje, FallaVehiculo, FechaMantenimiento, ServicioMantenimiento");

            for (PlanMantenimiento pm : listaMantenimientos) {
                pw.println(pm.getCodigo() + "," +
                           pm.getDatosTecnico() + "," +
                           pm.getTipoMantenimiento() + "," +
                           pm.getDatosVehiculo() + "," +
                           pm.getKilometraje() + "," +
                           pm.getFallaVehiculo() + "," +
                           pm.getFechaMantenimiento() + "," +
                           pm.getServicioMantenimiento());
            }

            System.out.println("Mantenimientos guardados correctamente.");
        } catch (Exception e) {
            System.out.println("Error al guardar los mantenimientos: " + e.getMessage());
        }
    }
    
    public void cargarMantenimientosDesdeArchivo() {
        listaMantenimientos.clear();
        // Intentamos leer el archivo
        verificarOCrearArchivo();
        try {
            File archivo = new File("data/mantenimientos.csv");
            Scanner sc = new Scanner(archivo);

            // Saltamos la primera linea (encabezado)
            if (sc.hasNextLine()) {
                sc.nextLine();
            }

            // Leemos linea por linea
            while (sc.hasNextLine()) {
                String linea = sc.nextLine(); // una linea completa del archivo
                String[] partes = linea.split(","); // separa los datos por comas
                // Si hay exactamente 8 datos, continuamos
                if (partes.length == 8) {
                    // Guardamos cada parte en una variable
                    String codigo = partes[0];
                    String datosTecnico = partes[1];
                    String tipoMantenimiento = partes[2];
                    String datosVehiculo = partes[3];
                    int kilometraje = Integer.parseInt(partes[4]);
                    String fallaVehiculo = partes[5];
                    String fechaMantenimiento = partes[6];
                    double servicioMantenimiento = Double.parseDouble(partes[7]);
                    // Creamos un nuevo objeto PlanMantenimiento
                    PlanMantenimiento pm = new PlanMantenimiento(codigo, datosTecnico, tipoMantenimiento, datosVehiculo, kilometraje, fallaVehiculo, fechaMantenimiento, servicioMantenimiento);
                    pm.setCodigo(codigo);
                    pm.setDatosTecnico(datosTecnico);
                    pm.setTipoMantenimiento(tipoMantenimiento);
                    pm.setDatosVehiculo(datosVehiculo);
                    pm.setKilometraje(kilometraje);
                    pm.setFallaVehiculo(fallaVehiculo);
                    pm.setFechaMantenimiento(fechaMantenimiento);
                    pm.setServicioMantenimiento(servicioMantenimiento);
                    // Lo agregamos a la lista
                    listaMantenimientos.add(pm);
                }
            }

            sc.close(); // Cerramos el lector del archivo
            System.out.println("Mantenimientos cargados correctamente.");
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error al cargar los mantenimientos: " + e.getMessage());
        }
    }
    
    private void verificarOCrearArchivo() {
        try {
            File carpeta = new File("data");
            if (!carpeta.exists()) {
                carpeta.mkdirs(); // Crea la carpeta si no existe
            }

            File archivo = new File("data/mantenimientos.csv");
            if (!archivo.exists()) {
                PrintWriter pw = new PrintWriter(archivo);
                // Agregamos el encabezado del CSV
                pw.println("Codigo,DatosTecnico,TipoMantenimiento,DatosVehiculo,Kilometraje,FallaVehiculo,FechaMantenimiento,ServicioMantenimiento");
                pw.close();
                System.out.println("Archivo mantenimientos.csv creado correctamente.");
            }
        } catch (Exception e) {
            System.out.println("Error al crear carpeta o archivo: " + e.getMessage());
        }
    }
}
