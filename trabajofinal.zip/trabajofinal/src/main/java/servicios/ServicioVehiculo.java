/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

//importa la clase
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import modelos.Vehiculo;
//importar herramientas
import java.util.ArrayList; //guardar lista de clientes
import java.util.Scanner; // leer lo que el usuario escribe
import java.util.regex.Pattern;

public class ServicioVehiculo {
    private ArrayList<Vehiculo> vehiculos;

    public ServicioVehiculo(ArrayList<Vehiculo> listaVehiculos) {
        this.vehiculos = listaVehiculos;
    }
    //crea lector
    private Scanner sc = new Scanner(System.in);
    
    public void MenuVehiculos(){
        cargarVehiculoDesdeArchivo(); // Carga datos desde archivo
        boolean salir = false;
        int opcion;
        while (!salir){
            System.out.println("\n--- MANTENIMIENTO DE VEHICULOS ---");
            System.out.println("1. Insertar vehiculo");
            System.out.println("2. Buscar vehiculo");
            System.out.println("3. Modificar vehiculo");
            System.out.println("4. Eliminar vehiculo");
            System.out.println("5. Listar vehiculo");
            System.out.println("6. Volver al menu vehiculo");
            System.out.println("7. Volver al menu principal");
            
            System.out.print("Opcion: ");
            String entrada = sc.nextLine(); // Leemos lo que el usuario escribe como texto        
            // Validamos si el usuario solo presiona ENTER sin escribir nada
            if (entrada.isEmpty()) {
                System.out.println("Debes escribir un numero del 1 al 7.");
                continue; // Volvemos al inicio del while para mostrar el menu de nuevo
            }
            //intenta ejecutar que algo saldria mal 
            try {
                // Intentamos convertir el texto a numero entero
                opcion = Integer.parseInt(entrada);
                // Evaluamos la opcion del usuario
                switch (opcion) {
                    case 1: InsertarVehiculo();
                    break;
                    case 2: BuscarVehiculo();
                        break;
                    case 3 : ModificarVehiculo();
                        break;
                    case 4 : EliminarVehiculo();
                        break;
                    case 5 : ListarVehiculo();
                        break;
                    case 6 : 
                       System.out.println("Regresando al menu Vehiculo");
                        break;
                    case 7 :      
                       System.out.println("Regresando al menu principal");
                       salir = true;  
                        break;
                    default:
                        System.out.println("Opcion no valida. Elige un numero del 1 al 7.");
                        break;
                }
             //cae en el error o atrapa el error
            } catch (NumberFormatException e) {
             
                System.out.println("Entrada invalida. Escribe solo numeros del 1 al 7.");
            }
        }
    }
    
    //Ingresar clientes con validaciones
    private void InsertarVehiculo() {
    System.out.println("\n--- INSERTAR VEHICULO ---");

    String placa, numeroSerie, anioFabricacion, color, cilindrada, duenio;
    int cantidadPuertas;
    
    boolean validador = false;
        String codigo = null;
        // Validador de codigo de tecnico
        do {
            System.out.print("Cree un codigo: ");
            codigo = sc.nextLine().trim();

            if (codigo.equals("")){
                System.out.print("Escriba un codigo");
            } else if (buscarCodigoVehiculo(codigo) != null) {
            System.out.println("Ya existe un vehiculo con ese codigo.");
            return;
            }else{
                validador=true;
            }
        }while(!validador);

    
    
    // Validacion de placa
    while (true) {
        System.out.print("Ingrese la placa (formato: L1L-123): ");
        placa = sc.nextLine().trim();
        if (Pattern.matches("[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}-[0-9]{3}", placa)) {
            break;
        } else {
            System.out.println("Formato de placa incorrecto. Intente de nuevo.");
        }
    }

    // Validacion de numero de serie (VIN)
    while (true) {
        System.out.print("Ingrese el numero de serie (ej. 1HGCM82633A004352): ");
        numeroSerie = sc.nextLine().trim();
        if (numeroSerie.matches("[A-HJ-NPR-Z0-9]{17}")) {
            break;
        } else {
            System.out.println("Numero de serie invalido. Debe tener 17 caracteres alfanumericos.");
        }
    }

    // Validacion de anio de fabricacion
    while (true) {
        System.out.print("Ingrese el anio de fabricacion (4 digitos): ");
        anioFabricacion = sc.nextLine().trim();
        if (anioFabricacion.matches("\\d{4}")) {
            break;
        } else {
            System.out.println("El anio debe tener exactamente 4 digitos. Intente de nuevo.");
        }
    }

    // Validacion de color
    while (true) {
        System.out.print("Ingrese el color: ");
        color = sc.nextLine().trim();
        if (color.matches("[A-Za-z]+")) {
            break;
        } else {
            System.out.println("El color solo puede contener letras. Intente de nuevo.");
        }
    }

    // Validacion de cantidad de puertas
    while (true) {
        System.out.print("Ingrese la cantidad de puertas (entre 1 y 10): ");
        if (sc.hasNextInt()) {
            cantidadPuertas = sc.nextInt();
            sc.nextLine(); // limpiar buffer
            if (cantidadPuertas >= 1 && cantidadPuertas <= 10) {
                break;
            } else {
                System.out.println("Debe estar entre 1 y 10.");
            }
        } else {
            System.out.println("Ingrese un numero valido.");
            sc.nextLine(); // limpiar entrada invalida
        }
    }

    // Validacion de cilindrada
    while (true) {
        System.out.print("Ingrese la cilindrada del vehiculo (solo numeros): ");
        cilindrada = sc.nextLine().trim();
        if (cilindrada.matches("\\d+")) {
            break;
        } else {
            System.out.println("La cilindrada debe ser un numero. Intente de nuevo.");
        }
    }

    // Validacion de duenio
    while (true) {
        System.out.print("Ingrese el nombre del duenio: ");
        duenio = sc.nextLine().trim();
        if (duenio.matches("[A-Za-z ]+")) {
            break;
        } else {
            System.out.println("El nombre solo puede contener letras y espacios.");
        }
    }

    Vehiculo vehiculo = new Vehiculo(codigo, placa, numeroSerie, anioFabricacion, color, cantidadPuertas, cilindrada, duenio);
    vehiculos.add(vehiculo);

    System.out.println("Vehiculo agregado exitosamente.");
    guardarVehiculoEnArchivo();
}
    
    
    private void BuscarVehiculo() {
        System.out.println("\n--- BUSCAR VEHICULO ---");
        sc.nextLine(); // Limpiar buffer

        System.out.print("Codigo: ");
        String codigo = sc.nextLine();

        Vehiculo vehiculo = buscarCodigoVehiculo(codigo);
        if (vehiculo != null) {
            vehiculo.mostrar();
        } else {
            System.out.println("Vehiculo no encontrado.");
        }
    }
    
    
    
    private void ModificarVehiculo() {
        System.out.println("\n--- MODIFICAR VEHICULO ---");
        sc.nextLine(); // Limpiar buffer
        
        System.out.print("Ingrese el codigo del vehiculo a modificar: ");
        String codigo = sc.nextLine();

        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getCodigo().equals(codigo)) {
                System.out.println("Vehiculo encontrado.");
                boolean continuar = true;

                while (continuar) {
                    int opcion = 0;

                    // Mostrar menu y validar opcion entre 1 y 8
                    while (true) {
                        System.out.println("\nQue desea modificar?");
                        System.out.println("1. Placa");
                        System.out.println("2. Numero de serie");
                        System.out.println("3. Anio de fabricacion");
                        System.out.println("4. Color");
                        System.out.println("5. Cantidad de puertas");
                        System.out.println("6. Cilindrada");
                        System.out.println("7. Duenio");
                        System.out.println("8. Terminar modificaciones");
                        System.out.print("Elija una opcion (1-8): ");

                        if (sc.hasNextInt()) {
                            opcion = sc.nextInt();
                            sc.nextLine(); // Limpiar buffer

                            if (opcion >= 1 && opcion <= 8) {
                                break;
                            } else {
                                System.out.println("Opcion fuera de rango. Intente de nuevo.");
                            }
                        } else {
                            System.out.println("Debe ingresar un numero valido.");
                            sc.nextLine(); // limpiar entrada invalida
                        }
                    }

                    switch (opcion) {
                        case 1:
                            while (true) {
                                System.out.print("Ingrese nueva placa (formato: L1L-123): ");
                                String nuevaPlaca = sc.nextLine();
                                if (Pattern.matches("[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}-[0-9]{3}", nuevaPlaca)) {
                                    vehiculo.setPlaca(nuevaPlaca);
                                    break;
                                } else {
                                    System.out.println("Formato de placa incorrecto. Intente de nuevo.");
                                }
                            }
                            break;

                        case 2:
                            System.out.print("Ingrese nuevo numero de serie: ");
                            vehiculo.setNumeroSerie(sc.nextLine());
                            break;

                        case 3:
                            while (true) {
                                System.out.print("Ingrese nuevo anio de fabricacion (4 digitos): ");
                                String nuevoAnio = sc.nextLine();
                                if (nuevoAnio.matches("\\d{4}")) {
                                    vehiculo.setAnioFabricacion(nuevoAnio);
                                    break;
                                } else {
                                    System.out.println("El anio debe tener exactamente 4 digitos. Intente de nuevo.");
                                }
                            }
                            break;

                        case 4:
                            while (true) {
                                System.out.print("Ingrese nuevo color: ");
                                String nuevoColor = sc.nextLine();
                                if (nuevoColor.matches("[A-Za-z]+")) {
                                    vehiculo.setColor(nuevoColor);
                                    break;
                                } else {
                                    System.out.println("El color solo puede contener letras. Intente de nuevo.");
                                }
                            }
                            break;

                        case 5:
                            while (true) {
                                System.out.print("Ingrese nueva cantidad de puertas (entre 1 y 10): ");
                                if (sc.hasNextInt()) {
                                    int puertas = sc.nextInt();
                                    sc.nextLine();
                                    if (puertas >= 1 && puertas <= 10) {
                                        vehiculo.setCantidadPuertas(puertas);
                                        break;
                                    } else {
                                        System.out.println("Debe estar entre 1 y 10.");
                                    }
                                } else {
                                    System.out.println("Ingrese un numero valido.");
                                    sc.nextLine();
                                }
                            }
                            break;

                        case 6:
                            while (true) {
                                System.out.print("Ingrese nueva cilindrada (solo numeros): ");
                                String nuevaCilindrada = sc.nextLine();
                                if (nuevaCilindrada.matches("\\d+")) {
                                    vehiculo.setCilindrada(nuevaCilindrada);
                                    break;
                                } else {
                                    System.out.println("La cilindrada debe ser un numero. Intente de nuevo.");
                                }
                            }
                            break;

                        case 7:
                            while (true) {
                                System.out.print("Ingrese nuevo duenio: ");
                                String nuevoDueno = sc.nextLine();
                                if (nuevoDueno.matches("[A-Za-z ]+")) {
                                    vehiculo.setDuenio(nuevoDueno);
                                    break;
                                } else {
                                    System.out.println("El nombre del duenio solo puede contener letras. Intente de nuevo.");
                                }
                            }
                            break;

                        case 8:
                            continuar = false;
                            continue;
                    }

                    // Preguntar si desea modificar otro dato
                    while (true) {
                        System.out.print("Desea modificar otro dato de este vehiculo? (si/no): ");
                        String respuesta = sc.nextLine().trim().toLowerCase();
                        if (respuesta.equals("si")) {
                            break; // seguir modificando
                        } else if (respuesta.equals("no")) {
                            continuar = false;
                            break;
                        } else {
                            System.out.println("Respuesta invalida. Por favor escriba 'si' o 'no'.");
                        }
                    }
                }
                System.out.println("Vehiculo modificado exitosamente.");
                guardarVehiculoEnArchivo();
                return;
            }
        }
        System.out.println("Vehiculo no encontrado.");
    }

    
    private void EliminarVehiculo(){
        System.out.println("\n--- ELIMINAR VEHICULO ---");
        sc.nextLine();

        System.out.println("Ingrese el codigo del vehiculo: ");
        String codigo = sc.nextLine();
        for (int i = 0; i < vehiculos.size(); i++) {
            if (vehiculos.get(i).getCodigo().equals(codigo)) {
                vehiculos.remove(i);
                System.out.println("Vehiculo eliminado exitosamente.");
                guardarVehiculoEnArchivo();
                return;
            }
        }
        System.out.println("Vehiculo no encontrado.");
    }

    
    private void ListarVehiculo() {
        System.out.println("\n--- LISTA DE VEHiCULOS ---");
        if (vehiculos.isEmpty()) {
            System.out.println("No hay vehículos registrados.");
        } else {
            for (Vehiculo v : vehiculos) {
            v.mostrar();
            System.out.println("-------------------------");
            }
        }
    }
    
    
    private Vehiculo buscarCodigoVehiculo(String codigo) {
    for (Vehiculo v : vehiculos) {
        if (v.getCodigo().equalsIgnoreCase(codigo)) {
            return v;
        }
    }
        return null;
    }
    
    public void guardarVehiculoEnArchivo() {
        //intentar hacer algo si falla
        try (PrintWriter pw = new PrintWriter("data/vehiculos.csv")) {
            pw.println("Codigo, Placa, Numero de serie, Anio de Fabricacion, Color, Cantidad de Puertas, Cilindrada, Duenio");
            //Para cada cliente que esté dentro de la lista de clientes, haz lo siguiente
            for (Vehiculo v : vehiculos) {
                //obtener los valores de cliente
                pw.println(v.getCodigo() + ", " +
                           v.getPlaca() + ", " +
                           v.getnumeroSerie() + ", " +
                           v.getAnioFabricacion() + ", " +
                           v.getColor() + ", " +
                           v.getCantidadPuertas() + ", " +
                           v.getCilindrada() + ", " +                         
                           v.getDuenio());
            }
            System.out.println("Vehiculos guardados correctamente.");
          //error 
          //guarda la informacion del error
        } catch (Exception e) {
            System.out.println("Error al guardar los vehiculos: " + e.getMessage());
        }
    }
    
    //metodo para cargar archivos
   public void cargarVehiculoDesdeArchivo() {
       vehiculos.clear();  //limpia la lista antes de cargar de nuevo
        try {
            // Verificamos si existe la carpeta "data", si no, la creamos
            File carpeta = new File("data");
            if (!carpeta.exists()) {
                carpeta.mkdirs();
            }

            // Verificamos si existe el archivo "vehiculos.csv"
            File archivo = new File("data/vehiculos.csv");
            if (!archivo.exists()) {
                PrintWriter pw = new PrintWriter(archivo);
                pw.println("Codigo,Placa,Numero de serie,Anio de Fabricacion,Color,Cantidad de Puertas,Cilindrada,Duenio");
                pw.close();
                System.out.println("Archivo vehiculos.csv creado correctamente.");
                return; // Como es nuevo, no hay nada más que leer
            }

            // Leemos el archivo
            Scanner sc = new Scanner(archivo);
            if (sc.hasNextLine()) {
                sc.nextLine(); // Saltamos la cabecera
            }

            while (sc.hasNextLine()) {
                String linea = sc.nextLine();
                String[] partes = linea.split(",");

                if (partes.length == 8) {
                    String codigo = partes[0].trim();
                    String placa = partes[1].trim();
                    String numeroSerie = partes[2].trim();
                    String anioFabricacion = partes[3].trim();
                    String color = partes[4].trim();
                    int cantidadPuertas = Integer.parseInt(partes[5].trim());
                    String cilindrada = partes[6].trim();
                    String duenio = partes[7].trim();

                    Vehiculo v = new Vehiculo(codigo, placa, numeroSerie, anioFabricacion, color, cantidadPuertas, cilindrada, duenio);
                    vehiculos.add(v);
                }
            }

            sc.close();
            System.out.println("Vehiculos cargados correctamente.");

        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error al cargar vehiculos: " + e.getMessage());
        }
    }
}
