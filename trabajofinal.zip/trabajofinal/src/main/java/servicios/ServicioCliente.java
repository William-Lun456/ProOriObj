/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios; 
//importa la clase
import modelos.Cliente;
//importar herramientas
import java.util.ArrayList; //guardar lista de clientes
import java.util.Scanner; // leer lo que el usuario escribe
import java.io.PrintWriter; // escribir texto en archivos
import java.io.File;  // manejar archivos del sistema(.txt, .csv, etc.)
import java.io.FileNotFoundException; //controlar errores si no se encuentra el archivo

public class ServicioCliente {
    // crea lista vacia clientes
    private ArrayList<Cliente> clientes = new ArrayList<>();
    //crea lector
    private Scanner sc = new Scanner(System.in);
    
    public void MenuClientes() {
        cargarClientesDesdeArchivo(); // Cargamos los clientes guardados desde el archivo

        boolean salir = false; // Variable para controlar si el usuario quiere salir del menu
        int opcion; // Aqui se guarda la opcion ingresada por el usuario

        while (!salir) { // Mientras no se elija salir
            // Mostramos el menu
            System.out.println("\n--- MANTENIMIENTO DE CLIENTES ---");
            System.out.println("1. Insertar cliente");
            System.out.println("2. Buscar cliente");
            System.out.println("3. Modificar cliente");
            System.out.println("4. Eliminar cliente");
            System.out.println("5. Listar clientes");
            System.out.println("6. Volver al menu cliente");
            System.out.println("7. Volver al menu principal");
            System.out.print("Opcion: ");

            String entrada = sc.nextLine(); // Leemos lo que el usuario escribe como texto

            // Validamos si el usuario solo presiona ENTER sin escribir nada
            if (entrada.isEmpty()) {
                System.out.println("Debes escribir un numero del 1 al 7.");
                continue; // Volvemos al inicio del while para mostrar el menu de nuevo
            }
            //intenta ejecutar que algo saldria mal 
            try {
                // Intentamos convertir el texto a numero entero
                opcion = Integer.parseInt(entrada);
                // Evaluamos la opcion del usuario
                switch (opcion) {
                    case 1:
                        InsertarCliente(); // Llama al metodo para insertar cliente
                        break;
                    case 2:
                        BuscarCliente(); // Llama al metodo para buscar cliente
                        break;
                    case 3:
                        ModificarCliente(); // Llama al metodo para modificar cliente
                        break;
                    case 4:
                        EliminarCliente(); // Llama al metodo para eliminar cliente
                        break;
                    case 5:
                        ListarCliente(); // Llama al metodo para listar clientes
                        break;
                    case 6:
                        System.out.println("Regresando al menu cliente.");
                        // No cambia nada porque ya estamos en este menu
                        break;
                    case 7:
                        System.out.println("Regresando al menu principal.");
                        salir = true; // Cambia la condicion para salir del bucle
                        break;
                    default:
                        System.out.println("Opcion no valida. Elige un numero del 1 al 7.");
                        break;
                }
             //cae en el error o atrapa el error
            } catch (NumberFormatException e) {
             
                System.out.println("Entrada invalida. Escribe solo numeros del 1 al 7.");
            }
        }
    }

    //Ingresar clientes con validaciones
    private void InsertarCliente(){
        System.out.println("\n--- INSERTAR CLIENTE ---");
         
        boolean validador = false;
        String codigo = null;
//        sc.nextLine();
        // Validador de codigo de tecnico
        do {
            System.out.print("Cree un codigo: ");
            codigo = sc.nextLine().trim();

            if (codigo.equals("")){
                System.out.print("Escriba un codigo");
            } else if (buscarCodigo(codigo) != null) {
            System.out.println("Ya existe un vehiculo con ese codigo.");
            return;
            }else{
                validador=true;
            }
        }while(!validador);

         System.out.print("Nombres: ");
         String nombres = sc.nextLine();
         
         System.out.print("Apellidos: ");
         String apellidos = sc.nextLine();
         
         String direccion;
         do{
             System.out.print("Ingrese su Direccion: ");
             direccion = sc.nextLine();
             if(direccion.isEmpty()){
                 System.out.println("La direccion no puede estar vacía.");
             }
         }while (direccion.isEmpty());
         
         String sexo = "";
         while(!sexo.equalsIgnoreCase("femenino")&& !sexo.equalsIgnoreCase("masculino")){
             System.out.print("Ingrese su genero(masculino/Femenino): ");
             sexo = sc.nextLine();
             
              if (!sexo.equalsIgnoreCase("masculino") && !sexo.equalsIgnoreCase("femenino")) {
                    System.out.println("Genero invalido.");
                }
           }
         
         String correo;
         do{
             System.out.print("Ingrese su Correo (ej: nombre@dominio.com): ");
             correo = sc.nextLine();
             if(!correo.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{3}$")){
              System.out.println("Correo invalido. Debe terminar en @dominio.com");
            }
         } while (!correo.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{3}$"));
         
         String celular;
         do{
             System.out.print("Ingrese su numero telefonico: ");
            celular = sc.nextLine();
            if (!celular.matches("^\\d{9}$")) {
                System.out.println("Telefono invalido. Debe tener exactamente 9 digitos.");
            }
        } while (!celular.matches("^\\d{9}$"));
         
         
        //instancia: objeto creado a partir de una clase  
        //Se crea un objeto con todos los datos del cliente cargados en sus atributos.
        Cliente cliente = new Cliente(codigo, nombres, apellidos, direccion, sexo, correo, celular);
        clientes.add(cliente);
        System.out.println("Cliente registrado correctamente.");
        guardarClientesEnArchivo();
    }
    
    
    //buscar a los clientes registradps
    private void BuscarCliente(){
        System.out.println("\n--- BUSCAR CLIENTE ---");
        sc.nextLine();
        
        System.out.print("Codigo: ");
        String codigo = sc.nextLine();
        
        Cliente cliente = buscarCodigo(codigo);
        if (cliente != null) {
            cliente.mostrar();
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }
    
    
    //modificacion de clientes
    private void ModificarCliente(){
        System.out.println("\n--- MODIFICAR CLIENTE ---");
        sc.nextLine();
        
        System.out.print("Codigo del cliente: ");
        String codigo = sc.nextLine();

        Cliente cliente = buscarCodigo(codigo);
        if (cliente != null) {
            System.out.println("Cliente encontrado. Puedes modificar sus datos:");
            
            System.out.print("Nuevo nombre: ");
            String nuevoNombre = sc.nextLine();
            cliente.setNombres(nuevoNombre);        

            System.out.print("Nuevo apellido: ");
            String nuevoApellido = sc.nextLine();
            cliente.setApellidos(nuevoApellido);
            
            String nuevaDireccion;
            do {
                System.out.print("Nueva direccion: ");
                nuevaDireccion = sc.nextLine().trim(); 

                if (nuevaDireccion.isEmpty()) {
                    System.out.println("Dirección vacia.");
                }
            } while (nuevaDireccion.isEmpty());
            cliente.setDireccion(nuevaDireccion);

            String nuevosexo = ""; 
            while (!nuevosexo.equalsIgnoreCase("femenino") && !nuevosexo.equalsIgnoreCase("masculino")) {
                System.out.print("Ingrese su genero (masculino/femenino): ");
                nuevosexo = sc.nextLine().trim();
                if (!nuevosexo.equalsIgnoreCase("masculino") && !nuevosexo.equalsIgnoreCase("femenino")) {
                    System.out.println("Genero inválido.");
                }
            }
            cliente.setSexo(nuevosexo); 

            String nuevocorreo;
            do {
                System.out.print("Nuevo correo: ");
                nuevocorreo = sc.nextLine();
                if (!nuevocorreo.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
                    System.out.println("Correo invalido.");
                }
            } while (!nuevocorreo.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$"));
            cliente.setCorreo(nuevocorreo);
            

            String nuevocelular;
            do {
                System.out.print("Nuevo numero telefonico: ");
                nuevocelular = sc.nextLine();
                if (!nuevocelular.matches("^\\d{9}$")) {
                    System.out.println("Celular invalido.");
                }
            } while (!nuevocelular.matches("^\\d{9}$"));
            cliente.setCelular(nuevocelular);

            System.out.println("Cliente modificado.");
            guardarClientesEnArchivo();
        } else {
            System.out.println("Cliente no encontrado.");         
        }
    }
    
    //Eliminacion de clientes
    private void EliminarCliente(){
        System.out.println("\n--- ELIMINAR CLIENTE ---");
        sc.nextLine();
        
        System.out.print("Codigo: ");
        String codigo = sc.nextLine();
        
        Cliente cliente = buscarCodigo(codigo);
        if(cliente != null){
            clientes.remove(cliente);
            System.out.println("Cliente eliminado.");   
            guardarClientesEnArchivo();
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }
    
    //listar clientes
    private void ListarCliente(){
         System.out.println("\n--- LISTA DE CLIENTES ---");
         
         if(clientes.isEmpty()){
             System.out.println("No hay clientes registrados.");
         } else {
             for(Cliente c : clientes){
                 c.mostrar();
                 System.out.println("-----------------------------"); // Línea separadora
             }
         }
    } 
    
    
    //crea un metodo
    private Cliente buscarCodigo(String codigo){
        //recorre la lista de clientes
        for(Cliente c : clientes){
            //obtiene el codigo actual y compara que no sean iguales
            if(c.getCodigo().equalsIgnoreCase(codigo)){
                return c;
            }  
        }
        return null;
    }
    
    
   //metodo para guardar datos 
   //Utiliza dentro de la clase 
   //void: no devuelve nada  
   //public: se puede usar desde otras clases.
   //private: usa desde la misma clase
    public void guardarClientesEnArchivo() {
        // Crear carpeta si no existe
        File carpeta = new File("data");
        if (!carpeta.exists()) {
            //.mkdirs() significa "make directories" o "crear carpetas".
            carpeta.mkdirs(); // crea la carpeta "data" si no existe
        }

        //intentar hacer algo si falla
        try (PrintWriter pw = new PrintWriter("data/clientes.csv")) {
            pw.println("Codigo, Nombres, Apellidos, Direccion, Sexo, Correo, Celular");

            for (Cliente c : clientes) {
                pw.println(c.getCodigo() + ", " +
                           c.getNombres() + ", " +
                           c.getApellidos() + ", " +
                           c.getDireccion() + ", " +
                           c.getSexo() + ", " +
                           c.getCorreo() + ", " +
                           c.getCelular());
            }

            System.out.println("Clientes guardados correctamente.");

        } catch (Exception e) {
            System.out.println("Error al guardar los clientes: " + e.getMessage());
        }
    }
    
    //metodo para cargar archivos
   public void cargarClientesDesdeArchivo() {
       clientes.clear(); // limpia la lista antes de volver a cargar
       //atrapa y maneja errores
       //podria causar un error
        try {
            //objeto dentro de la variable archico  -> se guarda en la ruta data/clientes
            File archivo = new File("data/clientes.csv"); // abre el archivo
            Scanner sc = new Scanner(archivo); // crea el lector

            if (sc.hasNextLine()) {  // verifica si hay una linea para leer
                sc.nextLine(); // salta la primera línea (cabecera)
            }

            while (sc.hasNextLine()) {
                String linea = sc.nextLine(); // lee una línea de texto completo del archivo (ej. C001,Juan,Pérez,Av. Lima,Masculino,juan@gmail.com,987654321)
                String[] partes = linea.split(","); // separa con comas y los pedazos se guarda en el arreglo de partes
                
                //verifica si estan las partes completas
                //partes.length -> cant. elementos que hay en el arreglo de partes 
                if(partes.length == 7){
                    // Captura los datos
                String codigo = partes[0];
                String nombres = partes[1];
                String apellidos = partes[2];
                String direccion = partes[3];
                String sexo = partes[4];
                String correo = partes[5];
                String celular = partes[6];
                
                // Crea el cliente y lo agrega a la lista
                Cliente c = new Cliente(codigo, nombres, apellidos, direccion, sexo, correo, celular);
                clientes.add(c);
                }              
            }

            sc.close(); // cierra el lector
            System.out.println("Clientes cargados desde el archivo.");
            //ocurre el error porque no encuentra el archivo
            // e es el objeto que contiene el mensaje de error 
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo: " + e.getMessage());
        }
    }
}
