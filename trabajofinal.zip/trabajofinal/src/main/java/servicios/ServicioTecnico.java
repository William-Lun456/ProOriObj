/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

// Clase importada
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import modelos.Tecnico;
//Importar herramientas
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ServicioTecnico {
    // crea lista vacia tecnicos
    private ArrayList<Tecnico> tecnicos;

    public ServicioTecnico(ArrayList<Tecnico> listaTecnicos) {
        this.tecnicos = listaTecnicos;
    }
    //crea lector
    private Scanner sc = new Scanner(System.in);
    
    public void MenuTecnicos(){
        cargarTecnicoDesdeArchivo(); // Carga datos desde archivo
        boolean salir = false;
        int opcion;
        while (!salir){
            System.out.println("\n--- MANTENIMIENTO DE TECNICOS ---");
            System.out.println("1. Insertar tecnico");
            System.out.println("2. Buscar tecnico");
            System.out.println("3. Modificar tecnico");
            System.out.println("4. Eliminar tecnico");
            System.out.println("5. Listar tecnicos");
            System.out.println("6. Volver al menu tecnico");
            System.out.println("7. Volver al menu principal");
            
            System.out.print("Opcion: ");
            String entrada = sc.nextLine(); // Leemos lo que el usuario escribe como texto

            // Validamos si el usuario solo presiona ENTER sin escribir nada
            if (entrada.isEmpty()) {
                System.out.println("Debes escribir un numero del 1 al 7.");
                continue; // Volvemos al inicio del while para mostrar el menu de nuevo
            }
            //intenta ejecutar que algo saldria mal 
            try {
                // Intentamos convertir el texto a numero entero
                opcion = Integer.parseInt(entrada);
                // Evaluamos la opcion del usuario
                switch (opcion) {
                    case 1: InsertarTecnico();
                    break;
                    case 2: BuscarTecnico();
                        break;
                    case 3 : ModificarTecnico();
                        break;
                    case 4 : EliminarTecnico();
                        break;
                    case 5 : ListarTecnico();
                        break;
                    case 6 : 
                       System.out.println("Regresando al menu Cliente");
                        break;
                    case 7 :      
                       System.out.println("Regresando al menu principal");
                       salir = true;  
                        break;   
                    default:
                        System.out.println("Opcion no valida. Elige un numero del 1 al 7.");
                        break;
                }
             //cae en el error o atrapa el error
            } catch (NumberFormatException e) {
             
                System.out.println("Entrada invalida. Escribe solo numeros del 1 al 7.");
            }
        }    
    }
    
    public void InsertarTecnico(){
        System.out.println("\n--------INSERTAR TECNICO-------");
        String nombre,apellido ;
        boolean validador = false;
        String codigo = null;

        // Validador de codigo de tecnico
        do {
            System.out.print("Ingrese codigo: ");
            codigo = sc.nextLine().trim();

            if (codigo.equals("")){
                System.out.print("Escriba un codigo");
            } else if (existeCodigo(codigo)) {
            System.out.println("El codigo ya existe, ingrese otro.");
            }else{
                validador=true;
            }
        }while(!validador);

        // Ingreso de nombres y apellidos
        System.out.print("Ingrese nombre: ");
         // consume el salto anterior
        nombre = sc.nextLine().trim();

        System.out.print("Ingrese apellido: ");
        apellido = sc.nextLine().trim();

        String direccion;
        //Validación de dirección
        do {
            System.out.print("Ingrese su direccion: ");
            direccion = sc.nextLine().trim();
            if (direccion.isEmpty()){
                System.out.println("Ingrese una direccion valida");
            }


        }while(direccion.isEmpty());

        //Validación de sexo
        String sexo = "";
            do {
                System.out.print("Ingrese su sexo (Femenino/Masculino): ");
                sexo = sc.nextLine().trim();

                    if (!sexo.equalsIgnoreCase("femenino") && !sexo.equalsIgnoreCase("masculino")) {
                    System.out.println("Ingrese uno de los generos validos (Femenino o Masculino).");
                    }
            } while (!sexo.equalsIgnoreCase("femenino") && !sexo.equalsIgnoreCase("masculino"));

                    System.out.println(" Genero ingresado correctamente.");

        //Validación correo
        String correo;
        do {
            System.out.print("Ingrese el correo electronico: ");
            correo = sc.nextLine().trim();

            if(!correo.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{3}$")){
                System.out.println("Correo invalido. Debe terminar en @Dominio.com");
            }

        }while(!correo.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{3}$"));

        //Ingreso de especialidad
        String especialidad;
        do {
            System.out.print("Ingrese su especialidad: ");
            especialidad = sc.nextLine().trim();
            if (especialidad.isEmpty()) {
                System.out.println("La especialidad no puede estar vacia.");
            }
        } while (especialidad.isEmpty());


        //Ingrese celular
       String celular;
        do {
            System.out.print("Ingrese su numero de celular (9 digitos):");
            celular = sc.nextLine().trim();

            if (celular.matches("\\d{9}") && !celular.equals("000000000")) {
                break; 
            }else {     
                System.out.println("Numero invalido. Debe tener 9 digitos y no puede ser solo ceros.");          
            }
        } while (true);

       //Ingresar tiempo de servicio               
        double tiempoServicio = 0;
        boolean entradaValida = false;

        while (!entradaValida) {
            System.out.print("Ingrese el tiempo de servicio realizado (ej. 1:45): ");
            String input = sc.next();

            // Validar si el formato es hora:minuto
            if (input.matches("\\d+:\\d+")) {
                String[] partes = input.split("[:\\.]");
                int horas = Integer.parseInt(partes[0]);
                int minutos = Integer.parseInt(partes[1]);

                if (minutos >= 0 && minutos < 60) {
                    tiempoServicio = horas + (minutos / 60.0);
                    entradaValida = true;
                } else {
                     System.out.println("Error: los minutos deben estar entre 0 y 59.");
                }

            } else if (input.matches("\\d+(\\.\\d+)?")) {
            // Si es un número decimal como 1.5 o entero como 2
            double valor = Double.parseDouble(input);
            int parteEntera = (int) valor; // solo la hora
            double decimal = valor - parteEntera; // la parte decimal

            int minutos = (int) Math.round(decimal * 60); // convertir decimal a minutos

            if (minutos >= 0 && minutos < 60) {
                tiempoServicio = valor;
                entradaValida = true;
            } else {
                System.out.println("Error: la parte decimal no puede representar mas de 59 minutos.");
            }
            } else {
                 System.out.println("Entrada invalida. Usa formatos como 2, 1.5 o 1:45.");
            }
         }


        
        Tecnico tecnico = new Tecnico(codigo, nombre, apellido, direccion, sexo, correo, especialidad,celular, tiempoServicio);
        tecnicos.add(tecnico);
        System.out.println("Tecnico registrado correctamente.");
        guardarTecnicoEnArchivo();

    }
    
    //metodo auxiliar existe
    private boolean existeCodigo(String codigo) {
        for (Tecnico tecnico : tecnicos) {
            if (tecnico.getCodigo().equalsIgnoreCase(codigo)) {
                return true;
            }
        }
        return false;
    }
    
    // Buscar a un tecnico
    public void BuscarTecnico(){
        System.out.println("------ BUSCAR TECNICO ------");
        sc.nextLine(); // limpiar buffer
        
        System.out.print("Ingrese el codigo del tecnico que desea buscar: ");
        String codigoBuscado = sc.nextLine().trim();

        boolean encontrado = false;
        for (Tecnico tecnico : tecnicos) {
            if (tecnico.getCodigo().equalsIgnoreCase(codigoBuscado)) {
                System.out.println("Tecnico encontrado");
                System.out.println(tecnico); // gracias al toString()
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontro ningun tecnico con ese codigo.");
        }
    }
  
    // Modificar datos de un tecnico 
    public void ModificarTecnico(){
        System.out.println("\n--- MODIFICAR TECNICO ---");
        sc.nextLine();
        
        System.out.print("Ingrese el codigo del tecnico: ");
        String codigo = sc.nextLine();
        
        for (Tecnico tecnico : tecnicos) {
            if (tecnico.getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("Se encontro tecnico");
                boolean continuar = true;

                while (continuar) {
                    int opcion = 0;

                    // Mostrar menu y validar opcion entre 1 y 8
                    while (true) {
                        System.out.println("\nQue desea modificar?");
                        System.out.println("1. Nombre");
                        System.out.println("2. Apellido");
                        System.out.println("3. Direccion");
                        System.out.println("4. Sexo");
                        System.out.println("5. Correo");
                        System.out.println("6. Especialidad");
                        System.out.println("7. Celular");
                        System.out.println("8. Tiempo de servicio");
                        System.out.println("9. Terminar modificaciones");
                        System.out.print("Elija una opcion (1-9): ");
                       
                        if (sc.hasNextInt()) {
                            opcion = sc.nextInt();
                            sc.nextLine(); // Limpiar buffer

                            if (opcion >= 1 && opcion <= 9) {
                                break;
                            } else {
                                System.out.println("Opcion fuera de rango. Intente de nuevo.");
                            }
                        } else {
                            System.out.println("Debe ingresar un numero valido.");
                            sc.nextLine(); // limpiar entrada invalida
                        }
                    }
                    
                    boolean encontrado = false;
                    switch (opcion){
                        case 1: 
                            System.out.print("Ingrese el nuevo nombre: ");
                            String nuevo_nombre = sc.nextLine();
                            tecnico.setNombres(nuevo_nombre);
                            System.out.println("Nombre actualizado.");
                            break;
 
                        case 2: 
                            System.out.print("Ingrese el nuevo apellido: ");
                            String nuevoApellido = sc.nextLine();
                            tecnico.setApellidos(nuevoApellido);
                            System.out.println("Apellido actualizado.");
                            break; 
                            
                        case 3:
                         System.out.print("Ingrese la nueva direccion: ");
                            String nuevaDireccion = sc.nextLine();
                            tecnico.setDireccion(nuevaDireccion);
                            System.out.println("Direccion actualizada.");
                            break;
                        
                        case 4:
                            System.out.print("Ingrese el nuevo sexo:");
                            String nuevoSexo = sc.nextLine();
                            tecnico.setSexo(nuevoSexo);
                            System.out.println("Sexo actualizado");
                            break;
                        
                        case 5: 
                             System.out.print("Ingrese el nuevo correo: ");
                                String nuevoCorreo = sc.nextLine();

                                Pattern patronCorreo = Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{3}$");
                                Matcher matcher = patronCorreo.matcher(nuevoCorreo);

                                if (matcher.matches()) {
                                    tecnico.setCorreo(nuevoCorreo);
                                    System.out.println("Correo actualizado.");
                                } else {
                                    System.out.println("Correo invalido, intentelo de nuevo");
                                }
                                break;
                            
                        case 6:
                            System.out.print("Ingrese la nueva especialidad: ");
                            String nuevaEspecialidad = sc.nextLine();
                            tecnico.setEspecialidad(nuevaEspecialidad);
                            System.out.println("Especialidad actualizada.");
                            break;
                        
                        
                        case 7:
                           System.out.print("Ingrese el nuevo numero de celular: ");
                            String nuevoNumero = sc.nextLine();

                            if (nuevoNumero.matches("\\d{9}") && !nuevoNumero.equals("000000000")) {
                                tecnico.setCelular(nuevoNumero);
                                System.out.println("Número actualizado.");
                            } else {
                                System.out.println("Numero invalido. Debe tener 9 digitos y no puede ser solo ceros.");
                            }
                            break;
                            
                       case 8:
                            System.out.print("Ingrese el nuevo tiempo de servicio: ");
                            String input = sc.next();
                            sc.nextLine(); // limpia el enter

                            double nuevoTiempo = 0;
                            boolean entradaValida = false;

                            // Validar formato
                            if (input.matches("\\d+:\\d+")) {
                                // Formato hora:minuto
                                String[] partes = input.split(":");
                                int horas = Integer.parseInt(partes[0]);
                                int minutos = Integer.parseInt(partes[1]);

                                if (minutos >= 0 && minutos < 60) {
                                    nuevoTiempo = horas + (minutos / 60.0);
                                    entradaValida = true;
                                } else {
                                    System.out.println("Error: los minutos deben estar entre 0 y 59.");
                                }

                            } else if (input.matches("\\d+(\\.\\d+)?")) {
                                // Formato decimal (ej. 1.5, 2.25)
                                double valor = Double.parseDouble(input);
                                int parteEntera = (int) valor;
                                double decimal = valor - parteEntera;

                                // Verifica que la parte decimal no sea 0.60 o más
                                if (decimal >= 0.60) {
                                    System.out.println("Error: los minutos no pueden ser mayores a 59.");
                                } else {
                                    nuevoTiempo = valor;
                                    entradaValida = true;
                                }

                            } else {
                                System.out.println("Dato invalido. Usa formatos como 2, 1.5 o 1:30.");
                            }

                            if (entradaValida) {
                                if (nuevoTiempo > 0) {
                                    tecnico.setTiempoServicio(nuevoTiempo);
                                    System.out.println("Tiempo de servicio actualizado.");
                                } else {
                                    System.out.println("El tiempo debe ser mayor que 0.");
                                }
                            }
                            break;
                            
                        case 9:
                          continuar = false;  
                          break;

                        }
                    
                        // Preguntar si desea modificar otro dato
                        while (true) {
                        System.out.print("Desea modificar otro dato de un tecnico? (si/no): ");
                        String respuesta = sc.nextLine().trim().toLowerCase();
                        if (respuesta.equals("si")) {
                            break; // seguir modificando
                        } else if (respuesta.equals("no")) {
                            continuar = false;
                            break;
                        } else {
                            System.out.println("Respuesta invalida. Por favor escriba 'si' o 'no'.");
                        }
                   } 
                            
                }
                
                System.out.println("Datos modificados exitosamente.");
                guardarTecnicoEnArchivo();
                return;                         
            }
        }  
        System.out.println("Tecnico no encontrado.");
    }
    
    
    
    // Eliminar un tecnico 
    public void EliminarTecnico(){
        System.out.println("-------- ELIMINAR TECNICO --------");
        sc.nextLine(); // Limpiar el buffer antes de leer con nextLine()

        System.out.print("Ingrese el codigo del tecnico a eliminar: ");
        String codigoEliminar = sc.nextLine().trim();

        boolean eliminado = false;

        for (int i = 0; i < tecnicos.size(); i++) {
            if (tecnicos.get(i).getCodigo().equalsIgnoreCase(codigoEliminar)) {
                tecnicos.remove(i); //  Elimina al técnico
                eliminado = true;
                break; // Sal del bucle si solo quieres eliminar uno
            }
        }

        if (eliminado) {
            System.out.println("Tecnico eliminado correctamente.");
            guardarTecnicoEnArchivo();
        } else {
                System.out.println("No se encontro un tecnico con ese codigo.");
        }
    }
    
    
    // Listar tecnicos
    public void ListarTecnico(){
        System.out.println("\n--- LISTA DE TECNICOS ---");
         
         if(tecnicos.isEmpty()){
             System.out.println("No hay tecnicos registrados.");
         } else {
             for(Tecnico tec : tecnicos){
                 System.out.println(tec);
                  System.out.println("------------------------------");
             }
         }

    }
    
    //metodo para guardar datos 
   //Utiliza dentro de la clase 
   //void: no devuelve nada  
   //public: se puede usar desde otras clases.
   //private: usa desde la misma clase
    public void guardarTecnicoEnArchivo() {
        try {
            // Verifica y crea la carpeta si no existe
            File carpeta = new File("data");
            if (!carpeta.exists()) {//crear una carpeta
                //.mkdirs() significa "make directories" o "crear carpetas".
                carpeta.mkdirs();
            }

            // Ahora sí puede crear el archivo dentro de la carpeta
            PrintWriter pw = new PrintWriter("data/tecnicos.csv"); // OJO: cambié clientes.csv por tecnicos.csv

            pw.println("Codigo, Nombres, Apellidos, Direccion, Sexo, Correo, Especialidad, Celular, Tiempo Servicio");

            for (Tecnico c : tecnicos) {
                pw.println(c.getCodigo() + ", " +
                           c.getNombres() + ", " +
                           c.getApellidos() + ", " +
                           c.getDireccion() + ", " +
                           c.getSexo() + ", " +
                           c.getCorreo() + ", " +
                           c.getEspecialidad() + ", " +
                           c.getCelular() + ", " +
                           c.getTiempoServicio());
            }

            pw.close(); // No olvides cerrar el PrintWriter
            System.out.println("Tecnicos guardados correctamente.");

        } catch (Exception e) {
            System.out.println("Error al guardar los tecnicos: " + e.getMessage());
        }
    }
    
    //metodo para cargar archivos
   public void cargarTecnicoDesdeArchivo() {
       tecnicos.clear(); //limpia la lista antes de ser cargada
       //atrapa y maneja errores
       //podria causar un error
        try {
            //objeto dentro de la variable archico  -> se guarda en la ruta data/clientes
            File archivo = new File("data/tecnicos.csv"); // abre el archivo
            Scanner sc = new Scanner(archivo); // crea el lector

            if (sc.hasNextLine()) {  // verifica si hay una linea para leer
                sc.nextLine(); // salta la primera línea (cabecera)
            }

            while (sc.hasNextLine()) {
                String linea = sc.nextLine(); // lee una línea de texto completo del archivo (ej. C001,Juan,Pérez,Av. Lima,Masculino,juan@gmail.com,987654321)
                String[] partes = linea.split(","); // separa con comas y los pedazos se guarda en el arreglo de partes
                
                //verifica si estan las partes completas
                //partes.length -> cant. elementos que hay en el arreglo de partes 
                if(partes.length == 9){
                    // Captura los datos
                String codigo = partes[0];
                String nombres = partes[1];
                String apellidos = partes[2];
                String direccion = partes[3];
                String sexo = partes[4];
                String especialidad = partes[5];
                String correo = partes[6];
                String celular = partes[7];
                //convierte de un texto a un  numero 
                double tiempoServicio = Double.parseDouble(partes[8]);
                
                // Crea el cliente y lo agrega a la lista
                Tecnico tec = new Tecnico(codigo, nombres, apellidos, direccion, sexo, especialidad, correo, celular, tiempoServicio);
                tecnicos.add(tec);
                }              
            }

            sc.close(); // cierra el lector
            System.out.println("Tecnicos cargados desde el archivo.");
            //ocurre el error porque no encuentra el archivo
            // e es el objeto que contiene el mensaje de error 
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo: " + e.getMessage());
        }
    }
   
}
