/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autenticacion;


import java.util.Scanner;
public class ServicioLogin {
    private final String usuarioValido = "admin";
    private final String contraseniaValido = "1234";
    
    private Scanner sc;
    
    public ServicioLogin(Scanner sc) {
        this.sc = sc;
    }
    public boolean autenticacion (){
        int intentos = 3;
        System.out.println("--- INICIO DE SESION ---");
        
        while(intentos > 0){
            System.out.print("Ingrese usario: ");
            String usuario = sc.nextLine().trim();
            
            System.out.print("Ingrese contrasenia: ");
            String contraseña = sc.nextLine().trim();
            
            if(usuario.equals(usuarioValido)&& contraseña.equals(contraseniaValido)){
                System.out.println("Acceso autorizado");
                return true;
            } else {
                intentos--;
                 System.out.println("Acceso denegado. Intentos restantes " + intentos);
            }
        }
        System.out.println("Demasiados intentos fallidos.");
        return false;
    }
}
