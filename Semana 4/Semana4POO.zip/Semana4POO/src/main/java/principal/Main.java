package principal;

import autenticacion.ServicioLogin;
import servicios.ServicioProducto;
import servicios.ServicioCliente;
import servicios.ServicioCompra;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ServicioLogin login = new ServicioLogin(sc);
        if (!login.autenticacion()) {
            System.out.println("Saliendo...");
            return;
        }

        ServicioProducto srvProductos = new ServicioProducto(sc);
        ServicioCliente  srvClientes  = new ServicioCliente(sc, srvProductos);
        ServicioCompra   srvCompras   = new ServicioCompra(sc, srvClientes, srvProductos);
        srvClientes.setServicioCompra(srvCompras);

        boolean salir = false;
        while (!salir) {
            System.out.println("\n=== TIENDA VIRTUAL DE CONSOLAS ===");
            System.out.println("1) Productos (almacén)");
            System.out.println("2) Clientes (registro + boleta)");
            System.out.println("3) Registrar compra manual");
            System.out.println("4) Historial de ventas");
            System.out.println("5) Salir");
            System.out.print("Opción: ");
            String op = sc.nextLine().trim();

            if (op.equals("1")) srvProductos.menuProductos();
            else if (op.equals("2")) srvClientes.menuClientes();
            else if (op.equals("3")) srvCompras.menuCompras();
            else if (op.equals("4")) srvCompras.listar();
            else if (op.equals("5")) { System.out.println("¡Hasta luego!"); salir = true; }
            else System.out.println("Opción inválida.");
        }

        sc.close();
    }
}
