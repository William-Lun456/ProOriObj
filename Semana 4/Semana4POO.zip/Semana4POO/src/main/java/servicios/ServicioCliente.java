package servicios;
/*Importa los modelos Cl(entidad q maneja) y Pr(Mostrar catalogo y validar su compra) */
import modelos.Cliente;
import modelos.Producto;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
/*Hereda de ServicioBase<Cliente>: reutiliza lista en memoria (lista),
 buscarPorCodigo, listar y el contrato de cargar/guardar CSV. */
public class ServicioCliente extends ServicioBase<Cliente> {
    //Reglas de validacion regex
    private static final String REG_COD_CLIENTE = "^[Cc]\\d+$";
    private static final String REG_COD_PRODUCTO = "^[Pp]\\d+$";
    private static final String REG_LETRAS = "^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$";
    private static final String REG_DIRECCION = "^[A-Za-zÁÉÍÓÚáéíóúÑñ0-9 #.,-]+$";
    private static final String REG_CORREO = "^[\\w.%+-]+@[\\w.-]+\\.[A-Za-z]{2,}$";
    private static final String REG_CELULAR_PE = "^9\\d{8}$";
//Dependencias:SP lista/busca produ y verifi stock y SC registra boletas
    private final ServicioProducto srvProductos;
    private ServicioCompra srvCompras;
//Constructor e inyeccion:Pasa al padre el Scanner y la ruta del CSV de clientes.
//Guarda la dependencia de productos. Carga clientes desde data/clientes.csv al iniciar
    public ServicioCliente(Scanner sc, ServicioProducto srvProductos) {
        super(sc, "data/clientes.csv");
        this.srvProductos = srvProductos;
        cargarDesdeArchivo();
    }
//Conecta con el ScOMPRA para q cuando haga compras se actualize el stock
    public void setServicioCompra(ServicioCompra srvCompras) { this.srvCompras = srvCompras; }
//Muestra el menu principal
    public void menuClientes() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- CLIENTES ---");
            System.out.println("1) Registrar cliente + compra (boleta)");
            System.out.println("2) Buscar por código");
            System.out.println("3) Modificar datos");
            System.out.println("4) Eliminar");
            System.out.println("5) Listar clientes");
            System.out.println("6) Guardar CSV");
            System.out.println("7) Volver");
            System.out.print("Opción: ");
            String op = sc.nextLine().trim();

            if (op.equals("1")) registrarClienteConCompra();
            else if (op.equals("2")) buscarUI();
            else if (op.equals("3")) modificar();
            else if (op.equals("4")) eliminar();
            else if (op.equals("5")) listar();
            else if (op.equals("6")) { guardarEnArchivo(); System.out.println("Guardado."); }
            else if (op.equals("7")) { guardarEnArchivo(); volver = true; }
            else System.out.println("Opción inválida.");
        }
    }
//Validazion del Cliente
    private String leerCodigoCliente(String prompt) {
        String codigo;
        do {
            System.out.print(prompt);
            codigo = sc.nextLine().trim();
            if (!codigo.matches(REG_COD_CLIENTE)) {
                System.out.println("Código inválido. Debe iniciar con 'C' o 'c' y números (ej: C001).");
            }
        } while (!codigo.matches(REG_COD_CLIENTE));
        return codigo;
    }

    private void registrarClienteConCompra() {
        String codigo = leerCodigoCliente("Código cliente: ");
        if (buscarPorCodigo(codigo) != null) { System.out.println("Ya existe ese código."); return; }

        String nombres;
        do { System.out.print("Nombres: "); nombres = sc.nextLine().trim();
            if (!nombres.matches(REG_LETRAS)) System.out.println("Solo letras y espacios.");
        } while (!nombres.matches(REG_LETRAS));

        String apellidos;
        do { System.out.print("Apellidos: "); apellidos = sc.nextLine().trim();
            if (!apellidos.matches(REG_LETRAS)) System.out.println("Solo letras y espacios.");
        } while (!apellidos.matches(REG_LETRAS));

        String direccion;
        do { System.out.print("Dirección: "); direccion = sc.nextLine().trim();
            if (!direccion.matches(REG_DIRECCION)) System.out.println("Use letras, números y símbolos (# . , -).");
        } while (!direccion.matches(REG_DIRECCION));

        String correo;
        do { System.out.print("Correo: "); correo = sc.nextLine().trim();
            if (!correo.matches(REG_CORREO)) System.out.println("Correo inválido.");
        } while (!correo.matches(REG_CORREO));

        String celular;
        do { System.out.print("Celular (9 dígitos, empieza con 9): "); celular = sc.nextLine().trim();
            if (!celular.matches(REG_CELULAR_PE)) System.out.println("Celular inválido.");
        } while (!celular.matches(REG_CELULAR_PE));

        lista.add(new Cliente(codigo, nombres, apellidos, direccion, correo, celular));
        guardarEnArchivo();
        System.out.println("Cliente registrado.");

        System.out.println("\n--- CATÁLOGO DISPONIBLE ---");
        srvProductos.listar();
        boolean mas = true;
        while (mas) {
            Producto elegido = null;
            while (elegido == null) {
                System.out.print("Código del producto (P...): ");
                String cp = sc.nextLine().trim();
                if (!cp.matches(REG_COD_PRODUCTO)) { System.out.println("Formato inválido. Ej: P001"); continue; }
                elegido = srvProductos.buscarPorCodigo(cp);
                if (elegido == null) System.out.println("No existe ese producto en almacén.");
                else {
                    int cant = 0;
                    while (true) {
                        System.out.print("Cantidad: ");
                        String s = sc.nextLine().trim();
                        try { cant = Integer.parseInt(s); } catch (Exception e) { cant = 0; }
                        if (cant <= 0) { System.out.println("Cantidad inválida."); continue; }
                        if (cant > elegido.getStock()) { System.out.println("Stock insuficiente. Stock actual: " + elegido.getStock()); continue; }
                        break;
                    }
                    if (srvCompras != null) { srvCompras.registrarCompraDirecta(codigo, elegido.getCodigo(), cant); }
                }
            }
            String r;
            do {
                System.out.print("¿Comprará algo más? (s/n): ");
                r = sc.nextLine().trim().toLowerCase();
                if (!(r.equals("s") || r.equals("si") || r.equals("n") || r.equals("no"))) System.out.println("Ingrese 's'/'si' o 'n'/'no'.");
            } while (!(r.equals("s") || r.equals("si") || r.equals("n") || r.equals("no")));
            mas = r.startsWith("s");
        }
        System.out.println("Boleta registrada en data/compras.csv (una línea por producto).");
    }

    private void modificar() {
        String codigo = leerCodigoCliente("Código del cliente a modificar: ");
        Cliente c = buscarPorCodigo(codigo);
        if (c == null) { System.out.println("Cliente no encontrado."); return; }

        String nombres;
        do { System.out.print("Nuevos nombres: "); nombres = sc.nextLine().trim();
            if (!nombres.matches(REG_LETRAS)) System.out.println("Solo letras y espacios.");
        } while (!nombres.matches(REG_LETRAS));
        c.setNombres(nombres);

        String apellidos;
        do { System.out.print("Nuevos apellidos: "); apellidos = sc.nextLine().trim();
            if (!apellidos.matches(REG_LETRAS)) System.out.println("Solo letras y espacios.");
        } while (!apellidos.matches(REG_LETRAS));
        c.setApellidos(apellidos);

        String direccion;
        do { System.out.print("Nueva dirección: "); direccion = sc.nextLine().trim();
            if (!direccion.matches(REG_DIRECCION)) System.out.println("Use letras, números y símbolos (# . , -).");
        } while (!direccion.matches(REG_DIRECCION));
        c.setDireccion(direccion);

        String correo;
        do { System.out.print("Nuevo correo: "); correo = sc.nextLine().trim();
            if (!correo.matches(REG_CORREO)) System.out.println("Correo inválido.");
        } while (!correo.matches(REG_CORREO));
        c.setCorreo(correo);

        String celular;
        do { System.out.print("Nuevo celular: "); celular = sc.nextLine().trim();
            if (!celular.matches(REG_CELULAR_PE)) System.out.println("Celular inválido.");
        } while (!celular.matches(REG_CELULAR_PE));
        c.setCelular(celular);

        System.out.println("Cliente modificado.");
        guardarEnArchivo();
    }

    private void buscarUI() {
        String codigo = leerCodigoCliente("Código a buscar: ");
        Cliente c = buscarPorCodigo(codigo);
        System.out.println(c == null ? "No encontrado." : c.toString());
    }

    private void eliminar() {
        String codigo = leerCodigoCliente("Código a eliminar: ");
        Cliente c = buscarPorCodigo(codigo);
        if (c == null) { System.out.println("No encontrado."); return; }
        lista.remove(c);
        System.out.println("Eliminado (pendiente de guardar).");
    }

    @Override
    protected void cargarDesdeArchivo() {
        lista.clear();
        File f = new File(ARCHIVO);
        if (!f.exists()) {
            System.out.println("(No hay CSV de clientes. Se creará al guardar.)");
            return;
        }
        try {
            java.util.Scanner fs = new java.util.Scanner(f, "UTF-8");
            while (fs.hasNextLine()) {
                String linea = fs.nextLine().trim();
                if (linea.isEmpty()) continue;
                lista.add(Cliente.fromCSV(linea));
            }
            fs.close();
            System.out.println("Clientes cargados: " + lista.size());
        } catch (Exception e) {
            System.out.println("Error al leer CSV: " + e.getMessage());
        }
    }

    @Override
    public void guardarEnArchivo() {
        try {
            File f = new File(ARCHIVO);
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            PrintWriter pw = new PrintWriter(f, "UTF-8");
            for (Cliente c : lista) pw.println(c.toCSV());
            pw.close();
        } catch (Exception e) {
            System.out.println("Error al guardar CSV: " + e.getMessage());
        }
    }
}
