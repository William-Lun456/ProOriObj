package servicios;

import java.util.Scanner;
import modelos.ConCodigo;
/*Clase abstracta y genérica: T debe implementar ConCodigo: no puede ser instanciado directamente y
 que requiere que sus métodos abstractos sean implementados por sus subclases*/
public abstract class ServicioBase<T extends ConCodigo> {
    /*las subclases pueden acceder directamente al Almacén en memoria de objetos T  */
    protected final java.util.List<T> lista = new java.util.ArrayList<T>();
    protected final Scanner sc;
    protected final String ARCHIVO;//Ruta del CSV asocidao a este servicio

    public ServicioBase(Scanner sc, String archivo) {//Constructor
        this.sc = sc;//Guarda el Scanner
        this.ARCHIVO = archivo;//Guarda el CSV
    }

    public T buscarPorCodigo(String codigo) {
        // Recorre y compara usando getCodigo().
        for (T t : lista) if (t.getCodigo().equalsIgnoreCase(codigo)) return t;
        return null;//En caso no pueDA MUESTra null
    }

    public void listar() {
        if (lista.isEmpty()) { System.out.println("Sin registros."); return; }//Por si esta vacio
        for (T t : lista) System.out.println(t);//los imprime
    }
/*abstract: no tiene cuerpo aquí; obliga a cada subclase SP Y SCl implementen como leer su csv 
 protected: solo lo usan esta clase y sus subclases*/
    protected abstract void cargarDesdeArchivo();
    public abstract void guardarEnArchivo(); //subclase debe definir cómo escribir lista → CSV.
}
