package servicios;

import modelos.Compra;
import modelos.Cliente;
import modelos.Producto;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
//Uso de regex 
public class ServicioCompra {
    private static final String ARCHIVO = "data/compras.csv";
    private static final String REG_COD_CLIENTE = "^[Cc]\\d+$";
    private static final String REG_COD_PRODUCTO = "^[Pp]\\d+$";

    private final List<Compra> compras = new ArrayList<Compra>();
    private final Scanner sc;
    private final ServicioCliente srvClientes;
    private final ServicioProducto srvProductos;
//Carga compras precias 
    public ServicioCompra(Scanner sc, ServicioCliente srvClientes, ServicioProducto srvProductos) {
        this.sc = sc;
        this.srvClientes = srvClientes;
        this.srvProductos = srvProductos;
        cargarDesdeArchivo();
    }
//Muestra menu  de compras
    public void menuCompras() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- REGISTRO DE COMPRAS ---");
            System.out.println("1) Registrar compra");
            System.out.println("2) Listar compras");
            System.out.println("3) Guardar CSV");
            System.out.println("4) Volver");
            System.out.print("Opción: ");
            String op = sc.nextLine().trim();

            if (op.equals("1")) registrarCompraInteractiva();
            else if (op.equals("2")) listar();
            else if (op.equals("3")) { guardarEnArchivo(); System.out.println("Guardado."); }
            else if (op.equals("4")) { guardarEnArchivo(); volver = true; }
            else System.out.println("Opción inválida.");
        }
    }
//Registrar compra (núcleo de negocio)
    public void registrarCompraDirecta(String codCliente, String codProducto, int cantidad) {
        if (codCliente == null || !codCliente.matches(REG_COD_CLIENTE)) {
            System.out.println("Código de cliente inválido.");
            return;
        }
        if (codProducto == null || !codProducto.matches(REG_COD_PRODUCTO)) {
            System.out.println("Código de producto inválido.");
            return;
        }
        Cliente cli = srvClientes.buscarPorCodigo(codCliente);
        if (cli == null) { System.out.println("Cliente no existe."); return; }
        Producto prod = srvProductos.buscarPorCodigo(codProducto);
        if (prod == null) { System.out.println("Producto no existe."); return; }
        if (cantidad <= 0 || cantidad > prod.getStock()) {
            System.out.println("Cantidad inválida o stock insuficiente.");
            return;
        }
        double precioU = prod.getPrecio();
        Compra compra = new Compra(Compra.ahoraISO(), codCliente, codProducto, cantidad, precioU);
        compras.add(compra);
        prod.setStock(prod.getStock() - cantidad);//Reduce el stock al realizar la compra
        srvProductos.guardarEnArchivo();//Persiste el inventario
        guardarEnArchivo();//Persiste la compra
        System.out.println("Compra guardada: " + compra.toCSV());
    }
//Pide al usuario códigos y cantidad y delega en registrarCompraDirecta
    private void registrarCompraInteractiva() {
        System.out.print("Código cliente (C...): ");
        String cc = sc.nextLine().trim();
        System.out.print("Código producto (P...): ");
        String cp = sc.nextLine().trim();
        int cant = leerIntPositivo("Cantidad: ");
        registrarCompraDirecta(cc, cp, cant);
    }
//Lista el historial de comrpas
    public void listar() {
        if (compras.isEmpty()) { System.out.println("Sin compras registradas."); return; }
        System.out.println("fecha,codCliente,codProducto,cantidad,precioUnitario,total");
        for (Compra c : compras) System.out.println(c.toCSV());
    }
//Utilitario: leer enteros positivosRepite hasta que el usuario ingrese un entero > 0
    private int leerIntPositivo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine().trim();
            try {
                int n = Integer.parseInt(s);
                if (n > 0) return n;
            } catch (Exception e) { }
            System.out.println("Número inválido.");
        }
    }
//Persistencia: cargar y guardar CSV
    private void cargarDesdeArchivo() {
        compras.clear();
        File f = new File(ARCHIVO);
        if (!f.exists()) { return; }
        try {
            java.util.Scanner fs = new java.util.Scanner(f, "UTF-8");
            while (fs.hasNextLine()) {
                String linea = fs.nextLine().trim();
                if (linea.isEmpty()) continue;
                compras.add(Compra.fromCSV(linea));
            }
            fs.close();
        } catch (Exception e) {
            System.out.println("Error al leer compras.csv: " + e.getMessage());
        }
    }

    public void guardarEnArchivo() {
        try {
            File f = new File(ARCHIVO);
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            PrintWriter pw = new PrintWriter(f, "UTF-8");
            for (Compra c : compras) pw.println(c.toCSV());
            pw.close();
        } catch (Exception e) {
            System.out.println("Error al guardar compras.csv: " + e.getMessage());
        }
    }
}
