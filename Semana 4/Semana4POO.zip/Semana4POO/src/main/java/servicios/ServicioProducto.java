package servicios;

import modelos.Producto;
import java.io.File;
import java.util.Scanner;
//Extiende ServicioBase<Producto>: hereda lista, buscarPorCodigo, l
//listar y el contrato de cargar/guardar CSV.El genérico <Producto> 
//funciona porque Producto implementa ConCodigo (tiene getCodigo()
public class ServicioProducto extends ServicioBase<Producto> {
    private static final String REG_COD_PRODUCTO = "^[Pp]\\d+$";
//Constructor:Llama a padre Sca y la ruta del CSV de productos.Carga el inventario desde disco al inicia
    public ServicioProducto(Scanner sc) {
        super(sc, "data/productos.csv");
        cargarDesdeArchivo();
    }
//Muetsra menu
    public void menuProductos() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- ALMACÉN (PRODUCTOS) ---");
            System.out.println("1) Agregar producto");
            System.out.println("2) Buscar por código");
            System.out.println("3) Modificar");
            System.out.println("4) Eliminar");
            System.out.println("5) Listar productos");
            System.out.println("6) Guardar CSV");
            System.out.println("7) Volver");
            System.out.print("Opción: ");
            String op = sc.nextLine().trim();

            if (op.equals("1")) insertar();
            else if (op.equals("2")) buscarUI();
            else if (op.equals("3")) modificar();
            else if (op.equals("4")) eliminar();
            else if (op.equals("5")) listar();
            else if (op.equals("6")) { guardarEnArchivo(); System.out.println("Guardado."); }
            else if (op.equals("7")) { guardarEnArchivo(); volver = true; }
            else System.out.println("Opción inválida.");
        }
    }

    public String leerCodigoProducto(String prompt) {
        String codigo;
        do {
            System.out.print(prompt);
            codigo = sc.nextLine().trim();
            if (!codigo.matches(REG_COD_PRODUCTO)) {
                System.out.println("Código inválido. Debe iniciar con 'P' o 'p' seguido de números (ej: P001, p123).");
            }
        } while (!codigo.matches(REG_COD_PRODUCTO));
        return codigo;
    }

    private void insertar() {
        String codigo = leerCodigoProducto("Código: ");
        if (buscarPorCodigo(codigo) != null) {
            System.out.println("Ya existe ese código.");
            return;
        }
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Categoría (Consola/Juego/Accesorio/Servicio): ");
        String categoria = sc.nextLine();
        System.out.print("Precio: ");
        double precio = leerDouble();
        System.out.print("Stock: ");
        int stock = leerInt();

        lista.add(new Producto(codigo, nombre, categoria, precio, stock));
        System.out.println("Producto agregado (pendiente de guardar).");
    }

    private void buscarUI() {
        String codigo = leerCodigoProducto("Código a buscar: ");
        Producto p = buscarPorCodigo(codigo);
        System.out.println(p == null ? "No encontrado." : p.toString());
    }

    private void modificar() {
        String codigo = leerCodigoProducto("Código a modificar: ");
        Producto p = buscarPorCodigo(codigo);
        if (p == null) { System.out.println("No encontrado."); return; }

        System.out.print("Nuevo nombre (" + p.getNombre() + "): ");
        String nombre = sc.nextLine();
        if (!nombre.isEmpty()) p.setNombre(nombre);

        System.out.print("Nueva categoría (" + p.getCategoria() + "): ");
        String categoria = sc.nextLine();
        if (!categoria.isEmpty()) p.setCategoria(categoria);

        System.out.print("Nuevo precio (" + p.getPrecio() + "): ");
        String sPrecio = sc.nextLine();
        if (!sPrecio.isEmpty()) {
            try { p.setPrecio(Double.parseDouble(sPrecio)); } catch (Exception e) { }
        }

        System.out.print("Nuevo stock (" + p.getStock() + "): ");
        String sStock = sc.nextLine();
        if (!sStock.isEmpty()) {
            try { p.setStock(Integer.parseInt(sStock)); } catch (Exception e) { }
        }

        System.out.println("Producto modificado (pendiente de guardar).");
    }

    private void eliminar() {
        String codigo = leerCodigoProducto("Código a eliminar: ");
        Producto p = buscarPorCodigo(codigo);
        if (p == null) { System.out.println("No encontrado."); return; }
        lista.remove(p);
        System.out.println("Eliminado (pendiente de guardar).");
    }

    @Override
    protected void cargarDesdeArchivo() {
        lista.clear();
        File f = new File(ARCHIVO);
        if (!f.exists()) {
            System.out.println("(No hay CSV de productos. Se creará al guardar.)");
            return;
        }
        try {
            java.util.Scanner fs = new java.util.Scanner(f, "UTF-8");
            while (fs.hasNextLine()) {
                String linea = fs.nextLine().trim();
                if (linea.isEmpty()) continue;
                lista.add(Producto.fromCSV(linea));
            }
            fs.close();
            System.out.println("Productos cargados: " + lista.size());
        } catch (Exception e) {
            System.out.println("Error al leer CSV: " + e.getMessage());
        }
    }

    @Override
    public void guardarEnArchivo() {
        try {
            java.io.File f = new java.io.File(ARCHIVO);
            java.io.File parent = f.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            java.io.PrintWriter pw = new java.io.PrintWriter(f, "UTF-8");
            for (Producto p : lista) pw.println(p.toCSV());
            pw.close();
        } catch (Exception e) {
            System.out.println("Error al guardar CSV: " + e.getMessage());
        }
    }

    private double leerDouble() {
        while (true) {
            String s = sc.nextLine().trim();
            try { return Double.parseDouble(s); }
            catch (Exception e) { System.out.print("Número inválido, intenta de nuevo: "); }
        }
    }
    private int leerInt() {
        while (true) {
            String s = sc.nextLine().trim();
            try { return Integer.parseInt(s); }
            catch (Exception e) { System.out.print("Número inválido, intenta de nuevo: "); }
        }
    }
}
