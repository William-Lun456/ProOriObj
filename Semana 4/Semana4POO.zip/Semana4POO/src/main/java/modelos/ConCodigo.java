package modelos; public interface ConCodigo { String getCodigo(); }
/*interfaz común que unifica Cliente y Producto para búsquedas/operaciones genéricas. */