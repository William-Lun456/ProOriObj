package modelos;
/*extends :Herencia client hereda atributos y metodos de persona y implements 
Obliga a que Cliente ofrezca String getCodigo() */
public class Cliente extends Persona implements ConCodigo {
    /*Dato de cliente encapsulado solo accediendo con set y get */
    private String codigo;
    /*Constructor:Recibe datos, inicializando con super en la SC persona,this inicializa el campo 
     * especifico de cliente*/
    public Cliente(String codigo, String nombres, String apellidos,
                   String direccion, String correo, String celular) {
        super(nombres, apellidos, direccion, correo, celular);
        this.codigo = codigo;
    }
/*getCodigo() satisface la interfaz ConCodigo. Esto permite que ServicioBase<T extends ConCodigo> 
pueda buscar por código sin conocer la clase concreta. */
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
/*Crea la linea CSV  */
    public String toCSV() {
        return codigo + "," + nombres + "," + apellidos + "," + direccion + "," + correo + "," + celular;
    }

    public static Cliente fromCSV(String linea) {
        String[] p = linea.split(",");
        String codigo    = p.length > 0 ? p[0].trim() : "";
        String nombres   = p.length > 1 ? p[1].trim() : "";
        String apellidos = p.length > 2 ? p[2].trim() : "";
        String direccion = p.length > 3 ? p[3].trim() : "";
        String correo    = p.length > 4 ? p[4].trim() : "";
        String celular   = p.length > 5 ? p[5].trim() : "";
        return new Cliente(codigo, nombres, apellidos, direccion, correo, celular);
    }

    public String toString() {
        return codigo + " | " + nombres + " " + apellidos + " | " + correo + " | " + celular + " | " + direccion;
    }
}
