package modelos;
/*obliga a exponer getCodigo() y permite que los servicios genéricos (como ServicioBase<T extends ConCodigo>) 
trabajen con “cualquier cosa que tenga código” (Cliente o Producto) */
public class Producto implements ConCodigo {
    private String codigo;
    private String nombre;
    private String categoria;
    private double precio;
    private int stock;
/*Constructor */
    public Producto(String codigo, String nombre, String categoria, double precio, int stock) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }
/*getCodigo() cumple la interfaz ConCodigo y es clave para que ServicioBase pueda 
buscar por código sin conocer el tipo. */
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public String toCSV() { return codigo + "," + nombre + "," + categoria + "," + precio + "," + stock; }

    public static Producto fromCSV(String linea) {
        String[] p = linea.split(",");
        String codigo   = p.length > 0 ? p[0].trim() : "";
        String nombre   = p.length > 1 ? p[1].trim() : "";
        String categoria= p.length > 2 ? p[2].trim() : "";
        double precio   = p.length > 3 ? parseDouble(p[3]) : 0.0;
        int stock       = p.length > 4 ? parseInt(p[4]) : 0;
        return new Producto(codigo, nombre, categoria, precio, stock);
    }
    /*Helpers privados */
    private static double parseDouble(String s){ try{return Double.parseDouble(s.trim());}catch(Exception e){return 0.0;} }
    private static int parseInt(String s){ try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;} }

    public String toString(){ return codigo + " | " + nombre + " | " + categoria + " | S/ " + precio + " | Stock: " + stock; }
}
