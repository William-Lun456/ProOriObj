package modelos;
/*Son protected para que las subclases (como Cliente) 
los accedan directamente; por eso en Cliente.toCSV() se usan sin getters. */
public class Persona {
    protected String nombres;
    protected String apellidos;
    protected String direccion;
    protected String correo;
    protected String celular;
/*Constructor:Inicia rodos los campos donde las subclases lo invocan con super  */
    public Persona(String nombres, String apellidos, String direccion, String correo, String celular) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.correo = correo;
        this.celular = celular;
    }

    public String getNombres() { return nombres; }
    public void setNombres(String nombres) { this.nombres = nombres; }
    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
    public String getCelular() { return celular; }
    public void setCelular(String celular) { this.celular = celular; }
}
