package modelos;
/*Marca de tiempo */
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Compra {
    private String fecha;
    private String codCliente;
    private String codProducto;
    private int cantidad;
    private double precioUnitario;
    private double total;
/*Constructor donde inicializa todos los campos */
    public Compra(String fecha, String codCliente, String codProducto, int cantidad, double precioUnitario) {
        this.fecha = fecha;
        this.codCliente = codCliente;
        this.codProducto = codProducto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.total = cantidad * precioUnitario;
    }

    public String toCSV() {
        return fecha + "," + codCliente + "," + codProducto + "," + cantidad + "," + precioUnitario + "," + total;
    }

    public static Compra fromCSV(String linea) {
        String[] p = linea.split(",");
        String fecha = p.length>0 ? p[0].trim() : "";
        String cc    = p.length>1 ? p[1].trim() : "";
        String cp    = p.length>2 ? p[2].trim() : "";
        int cant     = p.length>3 ? parseInt(p[3]) : 0;
        double pu    = p.length>4 ? parseDouble(p[4]) : 0.0;
        return new Compra(fecha, cc, cp, cant, pu);
    }
/*Devuelve la fecha/hora actual formateada (ej.: 2025-09-10 14:35) */
    public static String ahoraISO() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
    }
/*Helpers privados.Evitan reventar si el CSV trae algo inválido: devuelven 0. */
    private static double parseDouble(String s){ try{return Double.parseDouble(s.trim());}catch(Exception e){return 0.0;} }
    private static int parseInt(String s){ try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;} }
}
