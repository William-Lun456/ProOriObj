package autenticacion;

import java.io.Console;
import java.util.Scanner;

public class ServicioLogin {
    private final String usuarioValido = "admin";
    private final String contraseniaValida = "1234";
    private final Scanner sc;

    public ServicioLogin(Scanner sc) { this.sc = sc; }

    private String leerPassword() {
        Console cons = System.console();
        if (cons != null) {
            char[] pass = cons.readPassword("Contraseña: ");
            return pass == null ? "" : new String(pass);
        }
        System.out.print("Contraseña: ");
        return sc.nextLine();
    }

    public boolean autenticacion() {
        int intentos = 3;
        while (intentos > 0) {
            System.out.print("Usuario: ");
            String usuario = sc.nextLine().trim();
            String pass = leerPassword().trim();
            if (usuario.equals(usuarioValido) && pass.equals(contraseniaValida)) {
                System.out.println("Acceso autorizado");
                return true;
            }
            intentos--;
            System.out.println("Acceso denegado. Intentos restantes: " + intentos);
        }
        System.out.println("Demasiados intentos fallidos.");
        return false;
    }
}
